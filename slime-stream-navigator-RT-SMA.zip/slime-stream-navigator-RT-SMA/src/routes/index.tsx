import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { NetworkScene } from "@/components/rtsma/NetworkScene";
import { ChartsPanel } from "@/components/rtsma/ChartsPanel";
import { ControlPanel } from "@/components/rtsma/ControlPanel";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RT-SMA · Slime Mold IoT Network Optimization" },
      { name: "description", content: "Real-time slime-mold inspired multi-objective routing for dynamic IoT networks with LSTM traffic prediction and ACO/PSO comparison." },
    ],
  }),
  component: Index,
});

function Index() {
  const heroRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (heroRef.current) gsap.from(heroRef.current, { opacity: 0, y: -10, duration: 0.8, ease: "power2.out" });
  }, []);
  return (
    <div className="min-h-screen w-full p-3 lg:p-4 grid gap-3 lg:gap-4 lg:h-screen
                    grid-cols-1 lg:[grid-template-columns:280px_1fr_1fr]">
      <aside className="glass-strong rounded-2xl p-4 overflow-hidden lg:max-h-full max-h-[80vh]">
        <ControlPanel />
      </aside>

      <section className="relative rounded-2xl overflow-hidden glass min-h-[420px] lg:min-h-0">
        <NetworkScene />
        <div ref={heroRef} className="absolute top-4 left-4 right-4 flex items-start justify-between pointer-events-none">
          <div>
            <div className="text-[10px] tracking-[0.3em] text-primary/80 uppercase">Slime Mold Intelligence</div>
            <h2 className="text-xl font-semibold text-gradient">Adaptive IoT Routing</h2>
          </div>
          <div className="flex items-center gap-2 pointer-events-auto">
            <Link to="/research-lab" className="glass-strong rounded-lg px-3 py-1.5 text-[11px] font-semibold text-gradient hover:bg-white/5 border border-primary/30">
              AI Research Lab →
            </Link>
            <Link to="/command-center" className="glass-strong rounded-lg px-3 py-1.5 text-[11px] font-semibold text-gradient hover:bg-white/5 border border-primary/30">
              Delhi NCR Digital Twin →
            </Link>
            <Legend />
          </div>
        </div>
        <div className="absolute bottom-3 left-4 right-4 flex justify-between text-[10px] font-mono text-muted-foreground pointer-events-none">
          <span>SOURCE → SINK · particles = traffic flow</span>
          <span className="text-primary hidden sm:inline">D_e(t+1) = D_e(t) + α·(Q_e/Q_max) − β·D_e(t)</span>
        </div>
      </section>

      <section className="rounded-2xl overflow-hidden min-h-[600px] lg:min-h-0">
        <ChartsPanel />
      </section>
    </div>
  );
}

function Legend() {
  const items = [
    { c: "oklch(0.85 0.2 145)", l: "Source" },
    { c: "oklch(0.83 0.17 75)", l: "Sink" },
    { c: "oklch(0.82 0.18 195)", l: "Node" },
    { c: "oklch(0.85 0.2 130)", l: "RT-SMA path" },
  ];
  return (
    <div className="glass rounded-lg px-3 py-2 flex gap-3 text-[10px] pointer-events-auto">
      {items.map((i) => (
        <div key={i.l} className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full" style={{ background: i.c, boxShadow: `0 0 8px ${i.c}` }} />
          <span className="text-muted-foreground">{i.l}</span>
        </div>
      ))}
    </div>
  );
}
