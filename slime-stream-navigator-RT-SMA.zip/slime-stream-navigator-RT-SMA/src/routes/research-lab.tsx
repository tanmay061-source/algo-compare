import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import gsap from "gsap";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Legend,
} from "recharts";
import { FlowPredictor } from "@/lib/rtsma/lstm";
import { buildNCRNetwork, syntheticCongestionSeries, NCR_NODE_LABELS } from "@/lib/twin/research";
import { trainQLearning, defaultDQN } from "@/lib/twin/qlearn";
import { stepRTSMA, stepACO, stepPSO, defaultParams } from "@/lib/rtsma/algorithms";
import { adjacency, otherEnd, type EdgeT, type Network } from "@/lib/rtsma/network";

export const Route = createFileRoute("/research-lab")({
  head: () => ({
    meta: [
      { title: "AI Research Lab · LSTM Prediction · DQN · IEEE Benchmark" },
      { name: "description", content: "AI Prediction Center, DQN reinforcement-learning routing agent and IEEE-style algorithm benchmark for the Delhi NCR digital twin." },
    ],
  }),
  component: ResearchLab,
});

function ResearchLab() {
  const headRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (headRef.current) gsap.from(headRef.current, { opacity: 0, y: -8, duration: 0.6 });
  }, []);
  return (
    <div className="min-h-screen w-full p-3 lg:p-5 space-y-4">
      <header ref={headRef} className="glass-strong rounded-2xl px-4 py-3 flex flex-wrap items-center gap-3">
        <div className="w-2.5 h-2.5 rounded-full bg-primary animate-pulse" style={{ boxShadow: "0 0 12px hsl(var(--primary))" }} />
        <div>
          <div className="text-[10px] tracking-[0.3em] uppercase text-primary/80">AI Research Lab</div>
          <h1 className="text-lg font-semibold text-gradient leading-tight">
            LSTM Prediction · DQN Routing · IEEE Benchmark Suite
          </h1>
        </div>
        <div className="ml-auto flex items-center gap-2 text-[10px] font-mono">
          <Link to="/command-center" className="glass px-2 py-1 rounded-md hover:bg-white/5">← Command Center</Link>
          <Link to="/" className="glass px-2 py-1 rounded-md hover:bg-white/5">RT-SMA Lab</Link>
        </div>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <PredictionCenter />
        <DQNAgent />
      </div>
      <BenchmarkSuite />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* AI Prediction Center — real TF.js LSTM congestion forecasting      */
/* ------------------------------------------------------------------ */

function PredictionCenter() {
  const predictor = useRef(new FlowPredictor()).current;
  const [seriesSeed, setSeriesSeed] = useState(7);
  const [epochs, setEpochs] = useState(12);
  const series = useMemo(() => syntheticCongestionSeries(seriesSeed), [seriesSeed]);
  const [training, setTraining] = useState(false);
  const [loss, setLoss] = useState<number | null>(null);
  const [predictions, setPredictions] = useState<{ idx: number; actual: number; predicted?: number }[]>(
    series.map((v, i) => ({ idx: i, actual: v })),
  );

  useEffect(() => {
    setPredictions(series.map((v, i) => ({ idx: i, actual: v })));
  }, [series]);

  async function runTrain() {
    setTraining(true);
    setLoss(null);
    const half = Math.floor(series.length * 0.7);
    const { finalLoss } = await predictor.train(series.slice(0, half), epochs);
    // generate rolling 1-step predictions over the test half
    predictor.reset();
    await predictor.train(series.slice(0, half), epochs);
    const rolled: { idx: number; actual: number; predicted?: number }[] = series.map((v, i) => ({ idx: i, actual: v }));
    for (let i = 0; i < series.length; i++) {
      predictor.observe(series[i]);
      if (i >= half) rolled[i].predicted = predictor.predict();
    }
    setPredictions(rolled);
    setLoss(finalLoss);
    setTraining(false);
  }

  const accuracy = useMemo(() => {
    const test = predictions.filter((p) => p.predicted !== undefined);
    if (!test.length) return null;
    const mape =
      test.reduce((s, p) => s + Math.abs((p.predicted! - p.actual) / Math.max(1, p.actual)), 0) / test.length;
    return Math.max(0, 1 - mape);
  }, [predictions]);

  return (
    <section className="glass-strong rounded-2xl p-4 space-y-3">
      <header className="flex items-center justify-between">
        <div>
          <div className="text-[10px] tracking-[0.18em] uppercase text-primary/80">Module 1</div>
          <h2 className="text-base font-semibold">AI Prediction Center · LSTM</h2>
        </div>
        <span className="text-[10px] font-mono text-muted-foreground">TF.js · Window=5 · LSTM(8)→Dense(1)</span>
      </header>

      <div className="flex flex-wrap items-center gap-3 text-[11px]">
        <label className="flex items-center gap-2">Road seed
          <input type="number" value={seriesSeed} onChange={(e) => setSeriesSeed(+e.target.value || 1)}
                 className="w-16 bg-black/30 border border-white/10 rounded px-2 py-1 font-mono" />
        </label>
        <label className="flex items-center gap-2">Epochs
          <input type="number" value={epochs} min={2} max={30} onChange={(e) => setEpochs(+e.target.value || 8)}
                 className="w-16 bg-black/30 border border-white/10 rounded px-2 py-1 font-mono" />
        </label>
        <button onClick={runTrain} disabled={training}
                className="px-3 py-1.5 rounded-lg bg-primary/20 border border-primary/40 text-primary font-semibold hover:bg-primary/30 disabled:opacity-50">
          {training ? "Training…" : "Train LSTM"}
        </button>
        {loss !== null && (
          <span className="font-mono text-muted-foreground">loss={loss.toFixed(4)} · acc≈{((accuracy ?? 0) * 100).toFixed(1)}%</span>
        )}
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={predictions}>
            <CartesianGrid stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="idx" tick={{ fontSize: 10, fill: "#94a3b8" }} />
            <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
            <Tooltip contentStyle={{ background: "#0a0a1a", border: "1px solid rgba(255,255,255,0.1)" }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Line dataKey="actual" stroke="hsl(var(--primary))" dot={false} strokeWidth={1.6} name="Actual congestion" />
            <Line dataKey="predicted" stroke="#f59e0b" dot={false} strokeWidth={1.8} name="LSTM forecast" />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="text-[11px] text-muted-foreground leading-relaxed">
        Synthetic 24h congestion trace (5-min buckets) with dual rush peaks. The LSTM is trained on
        the first 70% and forecasts the remaining 30% one step ahead. Accuracy = 1 − MAPE.
      </p>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* DQN Routing Agent (tabular Q-learning) on Delhi NCR                */
/* ------------------------------------------------------------------ */

function DQNAgent() {
  const [src, setSrc] = useState(0);
  const [dst, setDst] = useState(NCR_NODE_LABELS.length - 1);
  const [episodes, setEpisodes] = useState(400);
  const [result, setResult] = useState<ReturnType<typeof trainQLearning> | null>(null);
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    // yield to UI
    await new Promise((r) => setTimeout(r, 30));
    const net = buildNCRNetwork(src, dst);
    const res = trainQLearning(net, { ...defaultDQN, episodes });
    setResult(res);
    setRunning(false);
  }

  const smoothed = useMemo(() => {
    if (!result) return [];
    const w = 10;
    return result.rewardHistory.map((_, i) => {
      const start = Math.max(0, i - w);
      const slice = result.rewardHistory.slice(start, i + 1);
      return { ep: i, reward: slice.reduce((a, b) => a + b, 0) / slice.length };
    });
  }, [result]);

  const pathNames = result
    ? result.finalPath.map((i) => NCR_NODE_LABELS[i]?.label.split(" · ")[0]).join(" → ")
    : "";

  return (
    <section className="glass-strong rounded-2xl p-4 space-y-3">
      <header className="flex items-center justify-between">
        <div>
          <div className="text-[10px] tracking-[0.18em] uppercase text-primary/80">Module 2</div>
          <h2 className="text-base font-semibold">DQN Routing Agent · Q-Learning</h2>
        </div>
        <span className="text-[10px] font-mono text-muted-foreground">ε-greedy · γ=0.92 · α=0.35</span>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
        <Select label="Source" value={src} onChange={setSrc} />
        <Select label="Destination" value={dst} onChange={setDst} />
        <label className="flex flex-col gap-1">
          <span className="text-muted-foreground">Episodes</span>
          <input type="number" value={episodes} min={50} max={2000} step={50}
                 onChange={(e) => setEpisodes(+e.target.value || 400)}
                 className="bg-black/30 border border-white/10 rounded px-2 py-1 font-mono" />
        </label>
        <button onClick={run} disabled={running || src === dst}
                className="self-end px-3 py-1.5 rounded-lg bg-primary/20 border border-primary/40 text-primary font-semibold hover:bg-primary/30 disabled:opacity-50">
          {running ? "Training…" : "Train DQN"}
        </button>
      </div>

      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={smoothed}>
            <CartesianGrid stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="ep" tick={{ fontSize: 10, fill: "#94a3b8" }} label={{ value: "Episode", fontSize: 10, fill: "#94a3b8", position: "insideBottom", offset: -2 }} />
            <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
            <Tooltip contentStyle={{ background: "#0a0a1a", border: "1px solid rgba(255,255,255,0.1)" }} />
            <Line dataKey="reward" stroke="#a3e635" dot={false} strokeWidth={1.8} name="Smoothed reward" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="text-[11px] font-mono text-muted-foreground space-y-1">
        <div>→ Greedy path cost: <span className="text-primary">{result?.finalCost.toFixed(2) ?? "—"}</span></div>
        <div className="break-words leading-relaxed">→ Path: {pathNames || "—"}</div>
        <div>→ Q-table size: {result?.qTable.size ?? 0} state–action pairs</div>
      </div>
    </section>
  );
}

function Select({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-muted-foreground">{label}</span>
      <select value={value} onChange={(e) => onChange(+e.target.value)}
              className="bg-black/30 border border-white/10 rounded px-2 py-1 font-mono">
        {NCR_NODE_LABELS.map((n) => <option key={n.idx} value={n.idx}>{n.label}</option>)}
      </select>
    </label>
  );
}

/* ------------------------------------------------------------------ */
/* IEEE Benchmark Suite — Dijkstra/RT-SMA/ACO/PSO/DQN over OD pairs   */
/* ------------------------------------------------------------------ */

function dijkstraCost(net: Network) {
  const adj = adjacency(net);
  const dist = new Map<number, number>();
  for (const n of net.nodes) dist.set(n.id, Infinity);
  dist.set(net.source, 0);
  const visited = new Set<number>();
  const prev = new Map<number, EdgeT | null>();
  while (visited.size < net.nodes.length) {
    let u = -1, best = Infinity;
    for (const [k, v] of dist) if (!visited.has(k) && v < best) { best = v; u = k; }
    if (u === -1 || best === Infinity) break;
    visited.add(u);
    if (u === net.sink) break;
    for (const e of adj.get(u) ?? []) {
      const v = otherEnd(e, u);
      const w = e.baseLatency * 0.6 + e.baseEnergy * 1.6 + (1 - e.reliability) * 14;
      const alt = (dist.get(u) ?? Infinity) + w;
      if (alt < (dist.get(v) ?? Infinity)) { dist.set(v, alt); prev.set(v, e); }
    }
  }
  // reconstruct edges to compute latency/energy/reliability
  let cur = net.sink;
  const edges: EdgeT[] = [];
  while (cur !== net.source) {
    const e = prev.get(cur);
    if (!e) return { latency: Infinity, energy: Infinity, reliability: 0, hops: 0 };
    edges.push(e);
    cur = otherEnd(e, cur);
  }
  return {
    latency: edges.reduce((s, e) => s + e.baseLatency, 0),
    energy: edges.reduce((s, e) => s + e.baseEnergy, 0),
    reliability: edges.reduce((s, e) => s * e.reliability, 1),
    hops: edges.length,
  };
}

interface BenchRow {
  algo: string; latency: number; energy: number; reliability: number; convergenceMs: number; hops: number;
}

function BenchmarkSuite() {
  const [trials, setTrials] = useState(5);
  const [running, setRunning] = useState(false);
  const [rows, setRows] = useState<BenchRow[]>([]);

  async function run() {
    setRunning(true);
    await new Promise((r) => setTimeout(r, 20));
    const accum: Record<string, { lat: number; en: number; rel: number; ms: number; hops: number; n: number }> = {};
    const algos = ["Dijkstra", "RT-SMA", "ACO", "PSO", "DQN"];
    for (const a of algos) accum[a] = { lat: 0, en: 0, rel: 0, ms: 0, hops: 0, n: 0 };

    for (let t = 0; t < trials; t++) {
      const src = Math.floor(Math.random() * NCR_NODE_LABELS.length);
      let dst = Math.floor(Math.random() * NCR_NODE_LABELS.length);
      if (dst === src) dst = (dst + 1) % NCR_NODE_LABELS.length;
      const net = buildNCRNetwork(src, dst);

      const t0 = performance.now();
      const dj = dijkstraCost(net);
      const djMs = performance.now() - t0;
      if (isFinite(dj.latency)) {
        accum.Dijkstra.lat += dj.latency; accum.Dijkstra.en += dj.energy;
        accum.Dijkstra.rel += dj.reliability; accum.Dijkstra.ms += djMs; accum.Dijkstra.hops += dj.hops; accum.Dijkstra.n++;
      }

      const sma = stepRTSMA(buildNCRNetwork(src, dst), defaultParams);
      if (isFinite(sma.metrics.avgLatency)) {
        accum["RT-SMA"].lat += sma.metrics.avgLatency; accum["RT-SMA"].en += sma.metrics.energy;
        accum["RT-SMA"].rel += sma.metrics.reliability; accum["RT-SMA"].ms += sma.metrics.convergenceMs;
        accum["RT-SMA"].hops += sma.metrics.pathLength; accum["RT-SMA"].n++;
      }
      const aco = stepACO(buildNCRNetwork(src, dst), defaultParams);
      if (isFinite(aco.metrics.avgLatency)) {
        accum.ACO.lat += aco.metrics.avgLatency; accum.ACO.en += aco.metrics.energy;
        accum.ACO.rel += aco.metrics.reliability; accum.ACO.ms += aco.metrics.convergenceMs;
        accum.ACO.hops += aco.metrics.pathLength; accum.ACO.n++;
      }
      const pso = stepPSO(buildNCRNetwork(src, dst), defaultParams);
      if (isFinite(pso.metrics.avgLatency)) {
        accum.PSO.lat += pso.metrics.avgLatency; accum.PSO.en += pso.metrics.energy;
        accum.PSO.rel += pso.metrics.reliability; accum.PSO.ms += pso.metrics.convergenceMs;
        accum.PSO.hops += pso.metrics.pathLength; accum.PSO.n++;
      }
      const tq = performance.now();
      const dqn = trainQLearning(buildNCRNetwork(src, dst), { ...defaultDQN, episodes: 200 });
      const dqnMs = performance.now() - tq;
      if (dqn.finalEdges.length) {
        const lat = dqn.finalEdges.reduce((s, e) => s + e.baseLatency, 0);
        const en = dqn.finalEdges.reduce((s, e) => s + e.baseEnergy, 0);
        const rel = dqn.finalEdges.reduce((s, e) => s * e.reliability, 1);
        accum.DQN.lat += lat; accum.DQN.en += en; accum.DQN.rel += rel;
        accum.DQN.ms += dqnMs; accum.DQN.hops += dqn.finalEdges.length; accum.DQN.n++;
      }
      // yield to UI per trial
      await new Promise((r) => setTimeout(r, 0));
    }

    const out: BenchRow[] = algos.map((a) => {
      const x = accum[a]; const n = Math.max(1, x.n);
      return {
        algo: a, latency: x.lat / n, energy: x.en / n, reliability: x.rel / n,
        convergenceMs: x.ms / n, hops: x.hops / n,
      };
    });
    setRows(out);
    setRunning(false);
  }

  return (
    <section className="glass-strong rounded-2xl p-4 space-y-3">
      <header className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <div className="text-[10px] tracking-[0.18em] uppercase text-primary/80">Module 3</div>
          <h2 className="text-base font-semibold">IEEE Algorithm Benchmark · Delhi NCR</h2>
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <label className="flex items-center gap-2">Trials
            <input type="number" value={trials} min={1} max={25}
                   onChange={(e) => setTrials(+e.target.value || 5)}
                   className="w-16 bg-black/30 border border-white/10 rounded px-2 py-1 font-mono" />
          </label>
          <button onClick={run} disabled={running}
                  className="px-3 py-1.5 rounded-lg bg-primary/20 border border-primary/40 text-primary font-semibold hover:bg-primary/30 disabled:opacity-50">
            {running ? "Benchmarking…" : "Run Benchmark"}
          </button>
        </div>
      </header>

      <div className="grid md:grid-cols-3 gap-3">
        <BenchChart title="Avg Latency (ms)" rows={rows} dk="latency" color="#60a5fa" />
        <BenchChart title="Energy" rows={rows} dk="energy" color="#f59e0b" />
        <BenchChart title="Reliability" rows={rows} dk="reliability" color="#a3e635" domain={[0, 1]} />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-[11px] font-mono">
          <thead className="text-muted-foreground">
            <tr className="border-b border-white/10">
              <th className="text-left py-1.5 pr-3">Algorithm</th>
              <th className="text-right pr-3">Latency</th>
              <th className="text-right pr-3">Energy</th>
              <th className="text-right pr-3">Reliability</th>
              <th className="text-right pr-3">Hops</th>
              <th className="text-right">Conv. (ms)</th>
            </tr>
          </thead>
          <tbody>
            {rows.length ? rows.map((r) => (
              <tr key={r.algo} className="border-b border-white/5">
                <td className="py-1.5 pr-3 font-semibold text-foreground">{r.algo}</td>
                <td className="text-right pr-3">{r.latency.toFixed(2)}</td>
                <td className="text-right pr-3">{r.energy.toFixed(2)}</td>
                <td className="text-right pr-3">{r.reliability.toFixed(3)}</td>
                <td className="text-right pr-3">{r.hops.toFixed(1)}</td>
                <td className="text-right">{r.convergenceMs.toFixed(1)}</td>
              </tr>
            )) : (
              <tr><td colSpan={6} className="text-center py-6 text-muted-foreground">Run a benchmark to populate IEEE-style comparison table.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-[11px] text-muted-foreground leading-relaxed">
        Each trial samples a random source–destination pair on the Delhi NCR graph and runs all five
        algorithms on identical topology &amp; weights. Lower latency/energy and higher reliability are better.
      </p>
    </section>
  );
}

function BenchChart({ title, rows, dk, color, domain }: {
  title: string; rows: BenchRow[]; dk: keyof BenchRow; color: string; domain?: [number, number];
}) {
  return (
    <div className="glass rounded-xl p-3">
      <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground mb-2">{title}</div>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={rows}>
            <CartesianGrid stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="algo" tick={{ fontSize: 10, fill: "#94a3b8" }} />
            <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} domain={domain as [number, number] | undefined} />
            <Tooltip contentStyle={{ background: "#0a0a1a", border: "1px solid rgba(255,255,255,0.1)" }} />
            <Bar dataKey={dk as string} fill={color} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
