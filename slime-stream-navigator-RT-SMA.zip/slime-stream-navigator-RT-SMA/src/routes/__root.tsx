import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { Toaster } from "@/components/ui/sonner";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "RT-SMA MINI PROJECT" },
      { name: "description", content: "RT-SMA optimizes dynamic IoT networks using slime mold algorithms and AI for real-time adaptive routing." },
      { name: "author", content: "Lovable" },
      { property: "og:title", content: "RT-SMA MINI PROJECT" },
      { property: "og:description", content: "RT-SMA optimizes dynamic IoT networks using slime mold algorithms and AI for real-time adaptive routing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:title", content: "RT-SMA MINI PROJECT" },
      { name: "twitter:description", content: "RT-SMA optimizes dynamic IoT networks using slime mold algorithms and AI for real-time adaptive routing." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/74438a5a-f193-421a-b807-5a4726d00b98/id-preview-c5f4003d--3b35d5a7-711c-4e7c-b87e-c9ccb7274107.lovable.app-1778007223921.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/74438a5a-f193-421a-b807-5a4726d00b98/id-preview-c5f4003d--3b35d5a7-711c-4e7c-b87e-c9ccb7274107.lovable.app-1778007223921.png" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (<><Outlet /><Toaster richColors theme="dark" position="top-right" /></>);
}
