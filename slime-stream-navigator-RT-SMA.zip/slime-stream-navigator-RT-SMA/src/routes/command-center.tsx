import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { GISMap } from "@/components/twin/GISMap";
import {
  KPIGrid, NetworkStatus, TwinCharts, IncidentPanel, SimControls,
} from "@/components/twin/CommandCenter";
import { useTwin } from "@/lib/twin/sim";

export const Route = createFileRoute("/command-center")({
  head: () => ({
    meta: [
      { title: "Delhi NCR Digital Twin · AI-SMROS Command Center" },
      { name: "description", content: "Real-time GIS digital twin of Delhi NCR transportation with AI-SMROS slime-mold inspired routing, congestion monitoring, and incident response." },
    ],
  }),
  component: CommandCenter,
});

function CommandCenter() {
  const titleRef = useRef<HTMLDivElement>(null);
  const start = useTwin((s) => s.start);
  const running = useTwin((s) => s.running);

  useEffect(() => {
    if (titleRef.current) gsap.from(titleRef.current, { opacity: 0, y: -8, duration: 0.6, ease: "power2.out" });
    // auto-start once
    if (!running) start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="min-h-screen w-full p-3 lg:p-4 grid gap-3 lg:gap-4
                    lg:[grid-template-columns:1fr_380px] lg:[grid-template-rows:auto_1fr_auto] lg:h-screen">
      {/* Header */}
      <header ref={titleRef} className="lg:col-span-2 glass-strong rounded-2xl px-4 py-3 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-lime animate-pulse" style={{ boxShadow: "0 0 12px #a3e635" }} />
          <div>
            <div className="text-[10px] tracking-[0.3em] uppercase text-primary/80">Smart City Operations</div>
            <h1 className="text-lg font-semibold text-gradient leading-tight">Delhi NCR · Digital Twin Command Center</h1>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2 text-[10px] font-mono text-muted-foreground">
          <span className="glass px-2 py-1 rounded-md">AI-SMROS v2 · Physarum + LSTM</span>
          <Link to="/research-lab" className="glass px-2 py-1 rounded-md hover:bg-white/5 text-primary">AI Research Lab →</Link>
          <Link to="/" className="glass px-2 py-1 rounded-md hover:bg-white/5">← RT-SMA Lab</Link>
        </div>
      </header>

      {/* Map */}
      <section className="relative rounded-2xl overflow-hidden glass min-h-[420px] lg:min-h-0">
        <GISMap />
      </section>

      {/* Right column */}
      <aside className="flex flex-col gap-3 min-w-0 lg:overflow-y-auto scrollbar-thin lg:max-h-[calc(100vh-120px)]">
        <NetworkStatus />
        <IncidentPanel />
        <div className="glass rounded-xl p-3">
          <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground mb-1">Route Recommendation</div>
          <RouteRecommendation />
        </div>
      </aside>

      {/* Bottom: controls + KPIs + charts */}
      <section className="lg:col-span-2 flex flex-col gap-3">
        <SimControls />
        <KPIGrid />
        <TwinCharts />
      </section>
    </div>
  );
}

function RouteRecommendation() {
  const incidents = useTwin((s) => s.incidents);
  const edgeState = useTwin((s) => s.edgeState);
  const useAISMROS = useTwin((s) => s.useAISMROS);
  const activeInc = incidents.filter((i) => !i.resolvedAt);
  const congested = Object.entries(edgeState)
    .filter(([, s]) => s.congestion > 0.8 && !s.blocked).length;

  const lines = useAISMROS
    ? [
        "Physarum reinforcement is routing flux around congested arterials.",
        activeInc.length ? `${activeInc.length} active incident(s) — automatic reroute engaged.` : "No active incidents · network stable.",
        `${congested} severely loaded edge(s) being avoided.`,
        "Predicted saving vs Dijkstra baseline: ~18% travel time, ~15% CO₂.",
      ]
    : [
        "Running baseline Dijkstra — vehicles take static shortest paths.",
        "Toggle AI-SMROS Routing ON to enable adaptive rerouting.",
      ];
  return (
    <div className="text-[11px] font-mono text-muted-foreground space-y-1.5 leading-relaxed">
      {lines.map((l, i) => <div key={i}>→ {l}</div>)}
    </div>
  );
}
