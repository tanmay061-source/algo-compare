import { useSim } from "@/lib/rtsma/store";
import { rowsToCSV, downloadFile, parseFile, type ParseReport } from "@/lib/rtsma/io";

export function exportRunReport() {
  const s = useSim.getState();
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");

  // 1) Markdown report
  const m = (x: number | undefined | null, d = 3) => (x == null || !Number.isFinite(x) ? "—" : x.toFixed(d));
  const winner = s.rtsma.metrics && s.aco.metrics && s.pso.metrics
    ? [["RT-SMA", s.rtsma.metrics.avgLatency], ["ACO", s.aco.metrics.avgLatency], ["PSO", s.pso.metrics.avgLatency]]
        .sort((a, b) => (a[1] as number) - (b[1] as number))[0][0]
    : "—";

  const md = `# RT-SMA Run Report
Generated: ${new Date().toLocaleString()}

## Configuration
- Dataset rows: ${s.dataset.length}
- Network nodes: ${s.network.nodes.length}, edges: ${s.network.edges.length}
- LSTM AI prediction: **${s.useAI ? "ON" : "OFF"}**${s.lstmReady ? ` (trained, loss=${m(s.lstmLoss)})` : " (untrained — using EMA fallback)"}
- Predicted flow (last step): ${m(s.predictedFlow, 2)} pkt/s
- Steps simulated: ${s.cursor}

### RT-SMA parameters
| α | β | w₁ (lat) | w₂ (erg) | w₃ (rel) |
|---|---|---------|---------|---------|
| ${s.params.alpha} | ${s.params.beta} | ${s.params.w1} | ${s.params.w2} | ${s.params.w3} |

## Algorithm comparison (last step)
| Algorithm | Avg Latency (ms) | Energy | Reliability | Convergence (ms) | Path length |
|-----------|------------------|--------|-------------|------------------|-------------|
| **RT-SMA** | ${m(s.rtsma.metrics?.avgLatency)} | ${m(s.rtsma.metrics?.energy)} | ${m(s.rtsma.metrics?.reliability)} | ${m(s.rtsma.metrics?.convergenceMs, 2)} | ${s.rtsma.metrics?.pathLength ?? "—"} |
| ACO        | ${m(s.aco.metrics?.avgLatency)} | ${m(s.aco.metrics?.energy)} | ${m(s.aco.metrics?.reliability)} | ${m(s.aco.metrics?.convergenceMs, 2)} | ${s.aco.metrics?.pathLength ?? "—"} |
| PSO        | ${m(s.pso.metrics?.avgLatency)} | ${m(s.pso.metrics?.energy)} | ${m(s.pso.metrics?.reliability)} | ${m(s.pso.metrics?.convergenceMs, 2)} | ${s.pso.metrics?.pathLength ?? "—"} |

**Best (lowest latency) at last step:** ${winner}

## Time-series summary (latency over ${s.history.length} steps)
| Algorithm | mean | min | max |
|-----------|------|-----|-----|
| RT-SMA | ${m(avg(s.history, "rtsma"))} | ${m(Math.min(...s.history.map(h => h.rtsma)))} | ${m(Math.max(...s.history.map(h => h.rtsma)))} |
| ACO    | ${m(avg(s.history, "aco"))}    | ${m(Math.min(...s.history.map(h => h.aco)))}    | ${m(Math.max(...s.history.map(h => h.aco)))} |
| PSO    | ${m(avg(s.history, "pso"))}    | ${m(Math.min(...s.history.map(h => h.pso)))}    | ${m(Math.max(...s.history.map(h => h.pso)))} |

---
RT-SMA equation: \`D_e(t+1) = D_e(t) + α·(Q_e/Qmax) − β·D_e(t)\`
Fitness: \`F(P) = w₁·(1/latency) + w₂·(1/energy) + w₃·reliability\`
`;

  downloadFile(`rtsma-report-${stamp}.md`, md, "text/markdown");
  // 2) CSV time-series
  if (s.history.length) {
    const rows = s.history.map((h, i) => ({
      t: h.t, rtsma_latency: h.rtsma, aco_latency: h.aco, pso_latency: h.pso,
      rtsma_energy: s.energyHistory[i]?.rtsma ?? "",
      aco_energy: s.energyHistory[i]?.aco ?? "",
      pso_energy: s.energyHistory[i]?.pso ?? "",
    }));
    downloadFile(`rtsma-series-${stamp}.csv`, rowsToCSV(rows), "text/csv");
  }
  // 3) JSON full state
  const json = {
    generatedAt: new Date().toISOString(),
    config: { params: s.params, useAI: s.useAI, lstmReady: s.lstmReady, lstmLoss: s.lstmLoss },
    summary: {
      rtsma: s.rtsma.metrics, aco: s.aco.metrics, pso: s.pso.metrics,
    },
    history: s.history, energyHistory: s.energyHistory,
  };
  downloadFile(`rtsma-state-${stamp}.json`, JSON.stringify(json, null, 2), "application/json");
}

function avg(arr: { rtsma: number; aco: number; pso: number }[], k: "rtsma" | "aco" | "pso") {
  if (!arr.length) return NaN;
  return arr.reduce((s, x) => s + x[k], 0) / arr.length;
}

export async function uploadDatasetFile(file: File): Promise<ParseReport> {
  const report = await parseFile(file);
  if (!report.rows.length) throw new Error(report.errors[0] ?? "No valid rows parsed");
  useSim.getState().loadDataset(report.rows);
  return report;
}
