// IoT network topology: nodes in 3D, edges with capacity and per-edge metrics
import type { IoTRow } from "./dataset";

export interface NodeT {
  id: number;
  x: number; y: number; z: number;
  alive: boolean;
  isSource?: boolean;
  isSink?: boolean;
}

export interface EdgeT {
  id: string;
  a: number; b: number;
  baseLatency: number;     // ms
  baseEnergy: number;      // arbitrary energy units per unit flow
  reliability: number;     // 0..1 (1 - attack risk)
  capacity: number;
  conductivity: number;    // D_e — adapted by RT-SMA
  flow: number;            // current traffic on edge
}

export interface Network { nodes: NodeT[]; edges: EdgeT[]; source: number; sink: number; }

function rng(seed: number) {
  let s = seed >>> 0;
  return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export function buildNetwork(nNodes = 22, seed = 7): Network {
  const r = rng(seed);
  const nodes: NodeT[] = [];
  // Distribute on a sphere shell for nice 3D viz
  for (let i = 0; i < nNodes; i++) {
    const phi = Math.acos(1 - 2 * (i + 0.5) / nNodes);
    const theta = Math.PI * (1 + Math.sqrt(5)) * i;
    const R = 6;
    nodes.push({
      id: i,
      x: R * Math.sin(phi) * Math.cos(theta),
      y: R * Math.sin(phi) * Math.sin(theta),
      z: R * Math.cos(phi),
      alive: true,
    });
  }
  nodes[0].isSource = true;
  nodes[nNodes - 1].isSink = true;

  // Build edges: connect each node to its k nearest neighbours
  const k = 4;
  const edgeMap = new Map<string, EdgeT>();
  for (let i = 0; i < nNodes; i++) {
    const dists = nodes.map((n, j) => ({ j, d: Math.hypot(n.x - nodes[i].x, n.y - nodes[i].y, n.z - nodes[i].z) }))
      .filter((x) => x.j !== i).sort((a, b) => a.d - b.d).slice(0, k);
    for (const { j, d } of dists) {
      const a = Math.min(i, j), b = Math.max(i, j);
      const key = `${a}-${b}`;
      if (edgeMap.has(key)) continue;
      edgeMap.set(key, {
        id: key, a, b,
        baseLatency: 2 + d * 1.5 + r() * 4,
        baseEnergy: 0.5 + d * 0.4 + r() * 0.3,
        reliability: 0.85 + 0.15 * r(),
        capacity: 80 + 40 * r(),
        conductivity: 0.5 + 0.5 * r(),
        flow: 0,
      });
    }
  }
  return { nodes, edges: [...edgeMap.values()], source: 0, sink: nNodes - 1 };
}

// Adjacency helper
export function adjacency(net: Network) {
  const adj: Map<number, EdgeT[]> = new Map();
  for (const n of net.nodes) adj.set(n.id, []);
  for (const e of net.edges) {
    if (!net.nodes[e.a].alive || !net.nodes[e.b].alive) continue;
    adj.get(e.a)!.push(e);
    adj.get(e.b)!.push(e);
  }
  return adj;
}

export function otherEnd(e: EdgeT, n: number) { return e.a === n ? e.b : e.a; }

// Apply current traffic from dataset row to network (used by all algos for fairness)
export function applyTrafficContext(net: Network, row: IoTRow) {
  // Attack flag affects reliability of random edges
  for (const e of net.edges) {
    const attackPenalty = row.attack_flag ? Math.max(0, e.reliability - 0.15) : e.reliability;
    e.reliability = 0.6 * e.reliability + 0.4 * attackPenalty; // smooth
  }
  return row;
}
