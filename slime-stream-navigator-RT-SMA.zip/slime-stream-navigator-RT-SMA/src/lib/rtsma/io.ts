import * as XLSX from "xlsx";
import type { IoTRow } from "./dataset";

export interface ParseReport {
  rows: IoTRow[];
  detected: { flow: string | null; latency: string | null; energy: string | null; attack: string | null };
  errors: string[];
  warnings: string[];
  stats: { totalRows: number; validRows: number; numericColumns: string[] };
  synthesized: string[]; // fields that had to be derived
}

const FLOW_KEYS    = ["flow_rate", "flow", "rate", "throughput", "traffic", "packets", "pkt", "bandwidth", "bps"];
const LATENCY_KEYS = ["latency", "delay", "rtt", "response_time", "ms"];
const ENERGY_KEYS  = ["packet_size", "energy", "size", "bytes", "power", "consumption", "residual_energy", "energy_mj"];
const ATTACK_KEYS  = ["attack_flag", "attack", "malicious", "anomaly", "label", "intrusion", "is_attack", "failure_probability"];

function findCol(headers: string[], keys: string[]): string | null {
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
  const H = headers.map((h) => ({ raw: h, n: norm(h) }));
  for (const k of keys) {
    const kn = norm(k);
    const exact = H.find((h) => h.n === kn);
    if (exact) return exact.raw;
  }
  for (const k of keys) {
    const kn = norm(k);
    const partial = H.find((h) => h.n.includes(kn) || kn.includes(h.n));
    if (partial) return partial.raw;
  }
  return null;
}

function toNum(v: unknown): number {
  if (v == null || v === "") return NaN;
  if (typeof v === "number") return v;
  const n = parseFloat(String(v).replace(/[^0-9eE.+-]/g, ""));
  return Number.isFinite(n) ? n : NaN;
}

/** Parse arbitrary tabular records into validated IoT time-series rows. */
export function parseRecords(records: Record<string, unknown>[]): ParseReport {
  const errors: string[] = [];
  const warnings: string[] = [];
  const synthesized: string[] = [];
  if (!records.length) {
    return { rows: [], detected: { flow: null, latency: null, energy: null, attack: null },
      errors: ["File contained no data rows"], warnings, stats: { totalRows: 0, validRows: 0, numericColumns: [] }, synthesized };
  }
  const headers = Object.keys(records[0]);
  const detected = {
    flow: findCol(headers, FLOW_KEYS),
    latency: findCol(headers, LATENCY_KEYS),
    energy: findCol(headers, ENERGY_KEYS),
    attack: findCol(headers, ATTACK_KEYS),
  };

  // Numeric columns for stats / fallback
  const numericCols: string[] = [];
  for (const h of headers) {
    const sample = records.slice(0, Math.min(20, records.length)).map((r) => toNum(r[h]));
    if (sample.filter(Number.isFinite).length >= sample.length * 0.6) numericCols.push(h);
  }

  if (!detected.flow) {
    warnings.push(`No flow/rate column detected — synthesizing from "${numericCols[0] ?? "row index"}"`);
    synthesized.push("flow_rate");
  }
  if (!detected.latency) { warnings.push("No latency/delay column — deriving latency from flow congestion model"); synthesized.push("latency"); }
  if (!detected.energy)  { warnings.push("No packet_size/energy column — using constant 512B baseline"); synthesized.push("packet_size"); }
  if (!detected.attack)  { warnings.push("No attack_flag column — assuming all-normal traffic"); synthesized.push("attack_flag"); }

  // Build rows
  const rawFlow: number[] = records.map((r) =>
    detected.flow ? toNum(r[detected.flow!]) : (numericCols[0] ? toNum(r[numericCols[0]]) : NaN));
  // Replace NaN with column mean
  const validFlow = rawFlow.filter(Number.isFinite);
  const meanFlow = validFlow.length ? validFlow.reduce((a, b) => a + b, 0) / validFlow.length : 80;
  const minF = Math.min(...validFlow, meanFlow);
  const maxF = Math.max(...validFlow, meanFlow);
  // Normalize to a usable packets/sec band [10, 200] when input ranges look unusual
  const needsNorm = !detected.flow || maxF > 1e4 || maxF - minF < 1e-6;
  const normFlow = (v: number) => {
    if (!Number.isFinite(v)) v = meanFlow;
    if (!needsNorm) return Math.max(1, v);
    if (maxF === minF) return 80;
    return 10 + 190 * ((v - minF) / (maxF - minF));
  };

  let validRows = 0;
  const rows: IoTRow[] = records.map((r, i) => {
    const flow = normFlow(rawFlow[i]);
    let latency = detected.latency ? toNum(r[detected.latency!]) : NaN;
    if (!Number.isFinite(latency) || latency <= 0) latency = Math.max(1, 6 + flow * 0.18);
    if (latency > 5000) { warnings.push(`Row ${i + 2}: clamped latency ${latency.toFixed(0)}ms`); latency = 5000; }

    let pkt = detected.energy ? toNum(r[detected.energy!]) : NaN;
    if (!Number.isFinite(pkt) || pkt <= 0) pkt = 512;
    // If energy looks like Joules / mJ (very large), scale to a packet-size band
    if (pkt > 4096) pkt = 120 + (pkt % 880);

    let attack: 0 | 1 = 0;
    if (detected.attack) {
      const v = r[detected.attack!];
      const n = toNum(v);
      if (Number.isFinite(n)) attack = n >= 0.5 ? 1 : 0;
      else attack = /^(1|true|yes|attack|malicious|anomaly)$/i.test(String(v ?? "")) ? 1 : 0;
    }
    if (Number.isFinite(flow) && Number.isFinite(latency)) validRows++;
    return { t: i, flow_rate: flow, latency, packet_size: Math.round(pkt), attack_flag: attack };
  }).filter((r) => Number.isFinite(r.flow_rate) && Number.isFinite(r.latency));

  if (!rows.length) errors.push("No usable rows after validation");
  if (warnings.length > 8) warnings.splice(8, warnings.length - 8, `…and ${warnings.length - 8} more`);

  return { rows, detected, errors, warnings, synthesized,
    stats: { totalRows: records.length, validRows, numericColumns: numericCols } };
}

export function parseCSVText(text: string): Record<string, unknown>[] {
  const lines = text.replace(/^\uFEFF/, "").trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  const split = (l: string) => l.split(/,|;|\t/).map((s) => s.trim().replace(/^"|"$/g, ""));
  const headers = split(lines[0]);
  return lines.slice(1).map((l) => {
    const c = split(l);
    const o: Record<string, unknown> = {};
    headers.forEach((h, i) => (o[h] = c[i]));
    return o;
  });
}

export async function parseFile(file: File): Promise<ParseReport> {
  const name = file.name.toLowerCase();
  let records: Record<string, unknown>[] = [];
  if (name.endsWith(".csv") || name.endsWith(".tsv") || name.endsWith(".txt")) {
    records = parseCSVText(await file.text());
  } else if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const ws = wb.Sheets[wb.SheetNames[0]];
    records = XLSX.utils.sheet_to_json(ws, { defval: null });
  } else {
    throw new Error(`Unsupported file type: ${file.name}. Use .csv or .xlsx`);
  }
  return parseRecords(records);
}

/** Back-compat: existing parseCSV signature returning IoTRow[] */
export function parseCSV(text: string): IoTRow[] {
  return parseRecords(parseCSVText(text)).rows;
}

export function rowsToCSV(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const keys = Object.keys(rows[0]);
  return [keys.join(","), ...rows.map((r) => keys.map((k) => r[k]).join(","))].join("\n");
}

export function downloadFile(filename: string, content: string, type = "text/plain") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
