// Deterministic synthetic IoT traffic dataset
// Columns: flow_rate, latency, packet_size, attack_flag

export interface IoTRow {
  t: number;
  flow_rate: number;   // packets/sec  (mapped -> traffic)
  latency: number;     // ms           (mapped -> delay)
  packet_size: number; // bytes        (mapped -> energy proxy)
  attack_flag: 0 | 1;  //              (mapped -> reliability)
}

// Mulberry32 PRNG for determinism
function prng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6D2B79F5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateDataset(n = 600, seed = 42): IoTRow[] {
  const r = prng(seed);
  const rows: IoTRow[] = [];
  for (let t = 0; t < n; t++) {
    // Diurnal flow pattern + bursty noise
    const base = 80 + 60 * Math.sin((t / n) * Math.PI * 4);
    const burst = r() < 0.06 ? 80 * r() : 0;
    const flow_rate = Math.max(5, base + burst + (r() - 0.5) * 20);
    // Latency correlates with flow (congestion)
    const latency = Math.max(1, 6 + flow_rate * 0.18 + (r() - 0.5) * 8);
    const packet_size = Math.round(120 + 800 * r());
    const attack_flag: 0 | 1 = r() < 0.08 ? 1 : 0;
    rows.push({ t, flow_rate, latency, packet_size, attack_flag });
  }
  return rows;
}

export function datasetStats(rows: IoTRow[]) {
  const n = rows.length;
  const sum = (k: keyof IoTRow) => rows.reduce((a, r) => a + (r[k] as number), 0);
  const attacks = rows.filter((r) => r.attack_flag === 1).length;
  return {
    n,
    avgFlow: sum("flow_rate") / n,
    avgLatency: sum("latency") / n,
    avgPacket: sum("packet_size") / n,
    attackRatio: attacks / n,
  };
}

// Pearson correlation matrix on numeric columns
export function correlation(rows: IoTRow[]) {
  const cols = ["flow_rate", "latency", "packet_size", "attack_flag"] as const;
  const data = cols.map((c) => rows.map((r) => r[c] as number));
  const means = data.map((arr) => arr.reduce((a, b) => a + b, 0) / arr.length);
  const stds = data.map((arr, i) => {
    const m = means[i];
    return Math.sqrt(arr.reduce((a, b) => a + (b - m) ** 2, 0) / arr.length) || 1e-9;
  });
  return cols.map((_, i) =>
    cols.map((__, j) => {
      const m1 = means[i], m2 = means[j], s1 = stds[i], s2 = stds[j];
      const cov = data[i].reduce((a, _v, k) => a + (data[i][k] - m1) * (data[j][k] - m2), 0) / data[i].length;
      return cov / (s1 * s2);
    }),
  );
}
