// Real TF.js LSTM traffic predictor.
// Architecture: LSTM(units=8) -> Dense(1). Trained on a sliding window of 5 steps.
// Falls back to EMA prediction until training completes.

import * as tf from "@tensorflow/tfjs";

const WINDOW = 5;

export class FlowPredictor {
  private model: tf.LayersModel | null = null;
  private window: number[] = [];
  private mean = 80;
  private std = 30;
  private trained = false;
  private training = false;

  get ready() { return this.trained; }
  get isTraining() { return this.training; }

  observe(v: number) {
    this.window.push(v);
    if (this.window.length > WINDOW) this.window.shift();
  }

  private buildModel() {
    const m = tf.sequential();
    m.add(tf.layers.lstm({ units: 8, inputShape: [WINDOW, 1] }));
    m.add(tf.layers.dense({ units: 1 }));
    m.compile({ optimizer: tf.train.adam(0.02), loss: "meanSquaredError" });
    return m;
  }

  /** Train the LSTM on a series. Resolves when finished. */
  async train(series: number[], epochs = 8): Promise<{ finalLoss: number }> {
    if (this.training) return { finalLoss: NaN };
    this.training = true;
    try {
      this.mean = series.reduce((a, b) => a + b, 0) / series.length;
      this.std = Math.sqrt(series.reduce((a, b) => a + (b - this.mean) ** 2, 0) / series.length) || 1;
      const norm = series.map((v) => (v - this.mean) / this.std);
      const xs: number[][][] = []; const ys: number[] = [];
      for (let i = 0; i + WINDOW < norm.length; i++) {
        xs.push(norm.slice(i, i + WINDOW).map((v) => [v]));
        ys.push(norm[i + WINDOW]);
      }
      if (!xs.length) { this.training = false; return { finalLoss: NaN }; }
      const xTensor = tf.tensor3d(xs);
      const yTensor = tf.tensor2d(ys, [ys.length, 1]);
      this.model?.dispose();
      this.model = this.buildModel();
      const hist = await this.model.fit(xTensor, yTensor, {
        epochs, batchSize: 16, shuffle: true, verbose: 0,
      });
      xTensor.dispose(); yTensor.dispose();
      this.trained = true;
      const losses = hist.history.loss as number[];
      return { finalLoss: losses[losses.length - 1] };
    } finally {
      this.training = false;
    }
  }

  predict(): number {
    if (!this.window.length) return this.mean;
    if (!this.model || !this.trained || this.window.length < WINDOW) {
      // EMA fallback
      const w = 0.65;
      const ema = this.window.reduce((a, b) => w * b + (1 - w) * a, this.window[0]);
      return Math.max(1, ema);
    }
    const norm = this.window.slice(-WINDOW).map((v) => [(v - this.mean) / this.std]);
    const input = tf.tensor3d([norm]);
    const out = this.model.predict(input) as tf.Tensor;
    const [yNorm] = out.dataSync();
    input.dispose(); out.dispose();
    return Math.max(1, yNorm * this.std + this.mean);
  }

  reset() { this.window = []; this.model?.dispose(); this.model = null; this.trained = false; }
}
