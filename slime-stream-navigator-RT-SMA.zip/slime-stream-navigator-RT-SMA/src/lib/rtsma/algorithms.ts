// RT-SMA, ACO, PSO routing algorithms operating on the SAME network.
// All compute REAL metrics: avg latency, energy, reliability, convergence time.

import { adjacency, otherEnd, type EdgeT, type Network } from "./network";

export interface PathResult {
  path: number[];        // node ids
  edges: EdgeT[];
  latency: number;
  energy: number;
  reliability: number;
  fitness: number;
}

export interface AlgoMetrics {
  avgLatency: number;
  energy: number;
  reliability: number;
  convergenceMs: number;
  iterations: number;
  pathLength: number;
}

export interface AlgoParams {
  alpha: number; // SMA reinforcement
  beta: number;  // SMA decay
  w1: number; w2: number; w3: number; // fitness weights
  predictedFlow: number;             // LSTM prediction (units of flow_rate)
}

export const defaultParams: AlgoParams = {
  alpha: 0.6, beta: 0.18, w1: 0.5, w2: 0.3, w3: 0.2, predictedFlow: 80,
};

// ---------- Shared utilities ----------

function pathFitness(edges: EdgeT[], p: AlgoParams): PathResult {
  const latency = edges.reduce((a, e) => a + e.baseLatency / Math.max(0.05, e.conductivity), 0);
  const energy = edges.reduce((a, e) => a + e.baseEnergy * (1 + p.predictedFlow / 200), 0);
  const reliability = edges.reduce((a, e) => a * e.reliability, 1);
  const fitness = p.w1 * (1 / Math.max(1e-6, latency)) + p.w2 * (1 / Math.max(1e-6, energy)) + p.w3 * reliability;
  return { path: [], edges, latency, energy, reliability, fitness };
}

// Dijkstra on a custom edge weight (used by all algos for path extraction)
function shortestPath(net: Network, weight: (e: EdgeT) => number): { path: number[]; edges: EdgeT[] } {
  const adj = adjacency(net);
  const dist = new Map<number, number>();
  const prev = new Map<number, { node: number; edge: EdgeT } | null>();
  for (const n of net.nodes) { dist.set(n.id, Infinity); prev.set(n.id, null); }
  dist.set(net.source, 0);
  const visited = new Set<number>();
  // simple O(n^2) priority — n is small
  while (visited.size < net.nodes.length) {
    let u = -1, best = Infinity;
    for (const [k, v] of dist) if (!visited.has(k) && v < best) { best = v; u = k; }
    if (u === -1 || best === Infinity) break;
    visited.add(u);
    if (u === net.sink) break;
    for (const e of adj.get(u) ?? []) {
      const v = otherEnd(e, u);
      if (!net.nodes[v].alive) continue;
      const alt = dist.get(u)! + weight(e);
      if (alt < dist.get(v)!) { dist.set(v, alt); prev.set(v, { node: u, edge: e }); }
    }
  }
  const path: number[] = []; const edges: EdgeT[] = [];
  let cur: number | null = net.sink;
  while (cur !== null && cur !== undefined) {
    path.unshift(cur);
    const p = prev.get(cur);
    if (!p) break;
    edges.unshift(p.edge);
    cur = p.node;
  }
  if (path[0] !== net.source) return { path: [], edges: [] };
  return { path, edges };
}

function buildResult(net: Network, edges: EdgeT[], params: AlgoParams, path: number[]): PathResult {
  const r = pathFitness(edges, params);
  r.path = path;
  return r;
}

// ---------- RT-SMA: slime mold conductivity adaptation ----------
// D_e(t+1) = D_e(t) + alpha * (|Q_e|/Qmax) - beta * D_e(t)
// Q_e is flow on edge e, computed as the "demand" along candidate paths weighted by fitness.

export function stepRTSMA(net: Network, p: AlgoParams): { result: PathResult; metrics: AlgoMetrics } {
  const start = performance.now();
  const iterations = 20;
  let best: PathResult | null = null;

  for (let it = 0; it < iterations; it++) {
    // Edge weight blends latency, energy, reliability and inverse conductivity
    const weight = (e: EdgeT) =>
      (p.w1 * e.baseLatency + p.w2 * e.baseEnergy * 4 + p.w3 * (1 - e.reliability) * 8) /
      Math.max(0.05, e.conductivity);

    const { path, edges } = shortestPath(net, weight);
    if (!path.length) break;
    const res = buildResult(net, edges, p, path);
    if (!best || res.fitness > best.fitness) best = res;

    // Compute Q_e = predicted flow routed along chosen path
    const Q = p.predictedFlow;
    const Qmax = Math.max(...net.edges.map((e) => e.capacity));
    const onPath = new Set(edges.map((e) => e.id));
    for (const e of net.edges) {
      const qe = onPath.has(e.id) ? Q : 0;
      e.conductivity = Math.max(0.02, e.conductivity + p.alpha * (qe / Qmax) - p.beta * e.conductivity);
      e.flow = 0.7 * e.flow + 0.3 * qe;
    }
  }

  const convergenceMs = performance.now() - start;
  if (!best) best = { path: [], edges: [], latency: Infinity, energy: Infinity, reliability: 0, fitness: 0 };
  return {
    result: best,
    metrics: {
      avgLatency: best.latency,
      energy: best.energy,
      reliability: best.reliability,
      convergenceMs,
      iterations,
      pathLength: best.path.length,
    },
  };
}

// ---------- ACO: Ant Colony Optimization ----------
export function stepACO(net: Network, p: AlgoParams): { result: PathResult; metrics: AlgoMetrics } {
  const start = performance.now();
  const ants = 12;
  const iterations = 15;
  const evapor = 0.25;
  const Q = 1.5;
  const pher = new Map<string, number>(net.edges.map((e) => [e.id, 1]));
  let best: PathResult | null = null;

  for (let it = 0; it < iterations; it++) {
    const antPaths: { edges: EdgeT[]; path: number[]; fitness: number }[] = [];
    for (let a = 0; a < ants; a++) {
      const visited = new Set<number>([net.source]);
      const path = [net.source]; const edgesUsed: EdgeT[] = [];
      let cur = net.source; let stuck = false;
      while (cur !== net.sink) {
        const adj = net.edges.filter((e) =>
          (e.a === cur || e.b === cur) &&
          net.nodes[otherEnd(e, cur)].alive &&
          !visited.has(otherEnd(e, cur)),
        );
        if (!adj.length) { stuck = true; break; }
        const probs = adj.map((e) => {
          const heur = 1 / (e.baseLatency + 0.1);
          return Math.pow(pher.get(e.id) ?? 1, 1.0) * Math.pow(heur, 2.0);
        });
        const sum = probs.reduce((a, b) => a + b, 0);
        let r = Math.random() * sum, idx = 0;
        for (; idx < probs.length; idx++) { r -= probs[idx]; if (r <= 0) break; }
        const chosen = adj[Math.min(idx, adj.length - 1)];
        edgesUsed.push(chosen);
        cur = otherEnd(chosen, cur);
        path.push(cur); visited.add(cur);
        if (path.length > net.nodes.length) { stuck = true; break; }
      }
      if (stuck) continue;
      const r = pathFitness(edgesUsed, p);
      antPaths.push({ edges: edgesUsed, path, fitness: r.fitness });
    }
    // evaporate
    for (const e of net.edges) pher.set(e.id, (pher.get(e.id) ?? 1) * (1 - evapor));
    // deposit
    for (const ap of antPaths) for (const e of ap.edges) pher.set(e.id, (pher.get(e.id) ?? 1) + Q * ap.fitness);
    // best
    for (const ap of antPaths) {
      const r = buildResult(net, ap.edges, p, ap.path);
      if (!best || r.fitness > best.fitness) best = r;
    }
  }
  const convergenceMs = performance.now() - start;
  if (!best) best = { path: [], edges: [], latency: Infinity, energy: Infinity, reliability: 0, fitness: 0 };
  return { result: best, metrics: {
    avgLatency: best.latency, energy: best.energy, reliability: best.reliability,
    convergenceMs, iterations, pathLength: best.path.length,
  } };
}

// ---------- PSO: Particle Swarm Optimization over edge-weight bias ----------
// Each particle proposes a per-edge weight scalar; we extract path via shortestPath.
export function stepPSO(net: Network, p: AlgoParams): { result: PathResult; metrics: AlgoMetrics } {
  const start = performance.now();
  const swarm = 10, iterations = 14;
  const dim = net.edges.length;
  type Particle = { pos: number[]; vel: number[]; best: number[]; bestFit: number };
  const particles: Particle[] = Array.from({ length: swarm }, () => {
    const pos = Array.from({ length: dim }, () => 0.5 + Math.random());
    return { pos, vel: pos.map(() => (Math.random() - 0.5) * 0.2), best: [...pos], bestFit: -Infinity };
  });
  let gBest: number[] = particles[0].pos.slice(); let gFit = -Infinity; let bestRes: PathResult | null = null;
  const w = 0.6, c1 = 1.4, c2 = 1.4;

  const evalParticle = (pos: number[]) => {
    const weight = (e: EdgeT) => {
      const idx = net.edges.indexOf(e);
      const bias = pos[idx] ?? 1;
      return bias * (p.w1 * e.baseLatency + p.w2 * e.baseEnergy * 4 + p.w3 * (1 - e.reliability) * 8);
    };
    const { path, edges } = shortestPath(net, weight);
    if (!path.length) return null;
    return buildResult(net, edges, p, path);
  };

  for (let it = 0; it < iterations; it++) {
    for (const part of particles) {
      const res = evalParticle(part.pos);
      if (!res) continue;
      if (res.fitness > part.bestFit) { part.bestFit = res.fitness; part.best = [...part.pos]; }
      if (res.fitness > gFit) { gFit = res.fitness; gBest = [...part.pos]; bestRes = res; }
    }
    for (const part of particles) {
      for (let i = 0; i < dim; i++) {
        const r1 = Math.random(), r2 = Math.random();
        part.vel[i] = w * part.vel[i] + c1 * r1 * (part.best[i] - part.pos[i]) + c2 * r2 * (gBest[i] - part.pos[i]);
        part.pos[i] = Math.max(0.1, Math.min(3, part.pos[i] + part.vel[i]));
      }
    }
  }
  const convergenceMs = performance.now() - start;
  const best = bestRes ?? { path: [], edges: [], latency: Infinity, energy: Infinity, reliability: 0, fitness: 0 };
  return { result: best, metrics: {
    avgLatency: best.latency, energy: best.energy, reliability: best.reliability,
    convergenceMs, iterations, pathLength: best.path.length,
  } };
}
