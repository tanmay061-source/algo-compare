import { create } from "zustand";
import { buildNetwork, applyTrafficContext, type Network } from "@/lib/rtsma/network";
import { generateDataset, datasetStats, correlation, type IoTRow } from "@/lib/rtsma/dataset";
import { stepRTSMA, stepACO, stepPSO, defaultParams, type AlgoMetrics, type AlgoParams, type PathResult } from "@/lib/rtsma/algorithms";
import { FlowPredictor } from "@/lib/rtsma/lstm";

export interface MetricSeries { t: number; rtsma: number; aco: number; pso: number }

interface SimState {
  network: Network;
  dataset: IoTRow[];
  cursor: number;
  running: boolean;
  useAI: boolean;
  params: AlgoParams;
  predictor: FlowPredictor;
  predictedFlow: number;
  rtsma: { result: PathResult | null; metrics: AlgoMetrics | null };
  aco: { result: PathResult | null; metrics: AlgoMetrics | null };
  pso: { result: PathResult | null; metrics: AlgoMetrics | null };
  history: MetricSeries[];
  energyHistory: MetricSeries[];
  // actions
  init: () => void;
  step: () => void;
  toggleRunning: () => void;
  toggleAI: () => void;
  setParam: <K extends keyof AlgoParams>(k: K, v: AlgoParams[K]) => void;
  failRandomNode: () => void;
  reset: () => void;
  loadDataset: (rows: IoTRow[]) => void;
  trainLSTM: () => Promise<void>;
  lstmReady: boolean;
  lstmTraining: boolean;
  lstmLoss: number | null;
}

function snapshotNetwork(net: Network): Network {
  return { ...net, nodes: net.nodes.map((n) => ({ ...n })), edges: net.edges.map((e) => ({ ...e })) };
}

export const useSim = create<SimState>((set, get) => ({
  network: buildNetwork(),
  dataset: generateDataset(),
  cursor: 0,
  running: false,
  useAI: true,
  params: { ...defaultParams },
  predictor: new FlowPredictor(),
  predictedFlow: 80,
  rtsma: { result: null, metrics: null },
  aco: { result: null, metrics: null },
  pso: { result: null, metrics: null },
  history: [],
  energyHistory: [],

  init: () => set({ network: buildNetwork(), dataset: generateDataset(), cursor: 0, history: [], energyHistory: [], predictor: new FlowPredictor() }),

  step: () => {
    const s = get();
    const row = s.dataset[s.cursor % s.dataset.length];
    s.predictor.observe(row.flow_rate);
    const predicted = s.useAI ? s.predictor.predict() : row.flow_rate;
    const params: AlgoParams = { ...s.params, predictedFlow: predicted };

    // Apply same traffic context to identical fresh copies for fairness
    const ctx = applyTrafficContext(s.network, row);
    void ctx;
    const netRT = snapshotNetwork(s.network);
    const netACO = snapshotNetwork(s.network);
    const netPSO = snapshotNetwork(s.network);

    const rt = stepRTSMA(netRT, params);
    const ac = stepACO(netACO, params);
    const ps = stepPSO(netPSO, params);

    // Persist conductivity adaptation from RT-SMA into the live network (its key feature)
    s.network.edges.forEach((e, i) => { e.conductivity = netRT.edges[i].conductivity; e.flow = netRT.edges[i].flow; });

    const t = s.cursor;
    const history = [...s.history, { t, rtsma: rt.metrics.avgLatency, aco: ac.metrics.avgLatency, pso: ps.metrics.avgLatency }].slice(-60);
    const energyHistory = [...s.energyHistory, { t, rtsma: rt.metrics.energy, aco: ac.metrics.energy, pso: ps.metrics.energy }].slice(-60);

    set({
      cursor: s.cursor + 1, predictedFlow: predicted,
      rtsma: { result: rt.result, metrics: rt.metrics },
      aco: { result: ac.result, metrics: ac.metrics },
      pso: { result: ps.result, metrics: ps.metrics },
      history, energyHistory,
    });
  },

  toggleRunning: () => set({ running: !get().running }),
  toggleAI: () => set({ useAI: !get().useAI }),
  setParam: (k, v) => set({ params: { ...get().params, [k]: v } }),
  failRandomNode: () => {
    const net = snapshotNetwork(get().network);
    const alive = net.nodes.filter((n) => n.alive && !n.isSource && !n.isSink);
    if (!alive.length) return;
    const victim = alive[Math.floor(Math.random() * alive.length)];
    victim.alive = false;
    set({ network: net });
  },
  reset: () => get().init(),
  lstmReady: false,
  lstmTraining: false,
  lstmLoss: null,
  loadDataset: (rows) => {
    const predictor = new FlowPredictor();
    set({
      dataset: rows, cursor: 0, history: [], energyHistory: [],
      predictor, lstmReady: false, lstmLoss: null,
    });
  },
  trainLSTM: async () => {
    const s = get();
    set({ lstmTraining: true });
    const series = s.dataset.map((r) => r.flow_rate);
    const { finalLoss } = await s.predictor.train(series, 8);
    set({ lstmTraining: false, lstmReady: s.predictor.ready, lstmLoss: finalLoss });
  },
}));

export function useDatasetAnalysis() {
  const ds = useSim((s) => s.dataset);
  return { stats: datasetStats(ds), corr: correlation(ds) };
}
