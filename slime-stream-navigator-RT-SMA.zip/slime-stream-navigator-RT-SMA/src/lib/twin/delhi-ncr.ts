// Delhi NCR transportation network — real-world coordinates.
// Nodes: major intersections, metro stations, terminals, highway junctions,
// logistics hubs, emergency centers. Edges: real arterial roads/expressways.

export type NodeKind =
  | "intersection"
  | "metro"
  | "bus_terminal"
  | "highway_junction"
  | "logistics"
  | "emergency";

export interface TwinNode {
  id: string;
  name: string;
  kind: NodeKind;
  lat: number;
  lng: number;
  city: "Delhi" | "Noida" | "Gurugram" | "Faridabad" | "Ghaziabad";
}

export interface TwinEdge {
  id: string;
  from: string;
  to: string;
  name: string;            // road name
  kind: "expressway" | "ring" | "arterial" | "highway";
  capacity: number;        // vehicles / 5min
}

export const NODES: TwinNode[] = [
  // Delhi
  { id: "n_cp",       name: "Connaught Place",       kind: "intersection",     lat: 28.6315, lng: 77.2167, city: "Delhi" },
  { id: "n_ndlsm",    name: "New Delhi Metro",       kind: "metro",            lat: 28.6428, lng: 77.2197, city: "Delhi" },
  { id: "n_isbtkg",   name: "ISBT Kashmere Gate",    kind: "bus_terminal",     lat: 28.6675, lng: 77.2289, city: "Delhi" },
  { id: "n_aiims",    name: "AIIMS Emergency",       kind: "emergency",        lat: 28.5672, lng: 77.2100, city: "Delhi" },
  { id: "n_dhaula",   name: "Dhaula Kuan Jn",        kind: "highway_junction", lat: 28.5917, lng: 77.1614, city: "Delhi" },
  { id: "n_iggi",     name: "IGI Airport T3",        kind: "logistics",        lat: 28.5562, lng: 77.0999, city: "Delhi" },
  { id: "n_naraina",  name: "Naraina Depot",         kind: "logistics",        lat: 28.6310, lng: 77.1395, city: "Delhi" },
  { id: "n_mukarba",  name: "Mukarba Chowk",         kind: "highway_junction", lat: 28.7430, lng: 77.1490, city: "Delhi" },
  { id: "n_saraikj",  name: "Sarai Kale Khan",       kind: "bus_terminal",     lat: 28.5895, lng: 77.2588, city: "Delhi" },
  { id: "n_akshrdm", name: "Akshardham Jn",         kind: "intersection",     lat: 28.6127, lng: 77.2773, city: "Delhi" },
  // Noida
  { id: "n_secn18",   name: "Sector 18 Noida",       kind: "intersection",     lat: 28.5705, lng: 77.3260, city: "Noida" },
  { id: "n_botgn",    name: "Botanical Garden",      kind: "metro",            lat: 28.5644, lng: 77.3340, city: "Noida" },
  { id: "n_pari",     name: "Pari Chowk",            kind: "highway_junction", lat: 28.4647, lng: 77.5028, city: "Noida" },
  { id: "n_dndflyo",  name: "DND Flyway",            kind: "highway_junction", lat: 28.5713, lng: 77.2906, city: "Noida" },
  // Gurugram
  { id: "n_iffco",    name: "IFFCO Chowk",           kind: "intersection",     lat: 28.4720, lng: 77.0729, city: "Gurugram" },
  { id: "n_hudaci",   name: "HUDA City Centre",      kind: "metro",            lat: 28.4593, lng: 77.0723, city: "Gurugram" },
  { id: "n_kherki",   name: "Kherki Daula Toll",     kind: "highway_junction", lat: 28.4072, lng: 76.9870, city: "Gurugram" },
  { id: "n_medanta",  name: "Medanta Emergency",     kind: "emergency",        lat: 28.4406, lng: 77.0410, city: "Gurugram" },
  { id: "n_rajiv",    name: "Rajiv Chowk Ggn",       kind: "highway_junction", lat: 28.4501, lng: 77.0710, city: "Gurugram" },
  // Faridabad
  { id: "n_badkhal",  name: "Badkhal Mor",           kind: "intersection",     lat: 28.4179, lng: 77.3010, city: "Faridabad" },
  { id: "n_fbdsec15", name: "Faridabad Sec-15",      kind: "metro",            lat: 28.3866, lng: 77.3115, city: "Faridabad" },
  { id: "n_escorts",  name: "Escorts Hospital",      kind: "emergency",        lat: 28.4089, lng: 77.3179, city: "Faridabad" },
  // Ghaziabad
  { id: "n_vaishali", name: "Vaishali Metro",        kind: "metro",            lat: 28.6448, lng: 77.3402, city: "Ghaziabad" },
  { id: "n_anandvih", name: "Anand Vihar ISBT",      kind: "bus_terminal",     lat: 28.6479, lng: 77.3158, city: "Ghaziabad" },
  { id: "n_ukbo",     name: "UP Border (NH-9)",      kind: "highway_junction", lat: 28.6336, lng: 77.3522, city: "Ghaziabad" },
];

const e = (from: string, to: string, name: string, kind: TwinEdge["kind"], capacity: number): TwinEdge => ({
  id: `${from}__${to}`, from, to, name, kind, capacity,
});

export const EDGES: TwinEdge[] = [
  // Inner Ring Road
  e("n_cp", "n_ndlsm", "Inner Ring Rd", "ring", 320),
  e("n_ndlsm", "n_isbtkg", "Inner Ring Rd", "ring", 320),
  e("n_isbtkg", "n_mukarba", "GT Karnal Rd", "highway", 280),
  e("n_cp", "n_aiims", "Inner Ring Rd", "ring", 300),
  e("n_aiims", "n_dhaula", "Ring Rd", "ring", 320),
  // Outer Ring Road
  e("n_dhaula", "n_naraina", "Outer Ring Rd", "ring", 360),
  e("n_naraina", "n_mukarba", "Outer Ring Rd", "ring", 360),
  e("n_aiims", "n_saraikj", "Ring Rd", "ring", 340),
  e("n_saraikj", "n_akshrdm", "Ring Rd", "ring", 320),
  e("n_akshrdm", "n_anandvih", "NH-9 link", "arterial", 280),
  // NH-48 / Delhi–Gurugram Expressway
  e("n_dhaula", "n_iggi", "NH-48", "expressway", 480),
  e("n_iggi", "n_iffco", "Delhi-Ggn Expy", "expressway", 520),
  e("n_iffco", "n_rajiv", "MG Road", "arterial", 260),
  e("n_iffco", "n_hudaci", "MG Road", "arterial", 260),
  e("n_rajiv", "n_medanta", "Sector Rd", "arterial", 220),
  e("n_rajiv", "n_kherki", "NH-48", "expressway", 500),
  // Noida–Greater Noida Expressway
  e("n_secn18", "n_botgn", "Sec-18 Link", "arterial", 240),
  e("n_botgn", "n_pari", "Noida-Gr.Noida Expy", "expressway", 460),
  e("n_secn18", "n_dndflyo", "DND Approach", "arterial", 300),
  e("n_dndflyo", "n_saraikj", "DND Flyway", "expressway", 440),
  // Yamuna Expressway link
  e("n_pari", "n_kherki", "Yamuna-KMP link", "expressway", 380),
  // NH-9 corridor
  e("n_akshrdm", "n_vaishali", "NH-9", "highway", 360),
  e("n_vaishali", "n_anandvih", "NH-9", "highway", 320),
  e("n_anandvih", "n_ukbo", "NH-9", "highway", 380),
  // Faridabad linkages
  e("n_saraikj", "n_badkhal", "Mathura Rd", "arterial", 280),
  e("n_badkhal", "n_fbdsec15", "Fbd Bypass", "arterial", 260),
  e("n_badkhal", "n_escorts", "Sec-12 Rd", "arterial", 200),
  e("n_fbdsec15", "n_pari", "FNG Link", "arterial", 240),
  // Cross-city
  e("n_secn18", "n_akshrdm", "DND/Noida Link", "arterial", 260),
  e("n_dndflyo", "n_botgn", "Mahamaya", "arterial", 240),
  e("n_hudaci", "n_kherki", "SPR", "arterial", 280),
];

export const CENTER: [number, number] = [28.55, 77.22];
