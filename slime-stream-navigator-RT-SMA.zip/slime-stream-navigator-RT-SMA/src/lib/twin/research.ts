// Research lab utilities: convert Delhi NCR twin graph into the rtsma Network
// format so we can fairly benchmark Dijkstra / RT-SMA / ACO / PSO / DQN on the
// SAME topology. Also exposes synthetic per-edge congestion time-series for the
// LSTM AI Prediction Center.

import { NODES, EDGES } from "./delhi-ncr";
import type { Network, EdgeT, NodeT } from "@/lib/rtsma/network";

const R_EARTH = 6371; // km
function hav(aLat: number, aLng: number, bLat: number, bLng: number) {
  const toR = (d: number) => (d * Math.PI) / 180;
  const dLat = toR(bLat - aLat), dLng = toR(bLng - aLng);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toR(aLat)) * Math.cos(toR(bLat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R_EARTH * Math.asin(Math.sqrt(x));
}

const idIndex = new Map(NODES.map((n, i) => [n.id, i]));

export function buildNCRNetwork(sourceIdx = 0, sinkIdx = NODES.length - 1): Network {
  // Project lat/lng to a local 2D plane for the 3D viz field (z=0)
  const lat0 = NODES.reduce((s, n) => s + n.lat, 0) / NODES.length;
  const lng0 = NODES.reduce((s, n) => s + n.lng, 0) / NODES.length;
  const scale = 70;
  const nodes: NodeT[] = NODES.map((n, i) => ({
    id: i,
    x: (n.lng - lng0) * scale,
    y: (n.lat - lat0) * scale,
    z: 0,
    alive: true,
    isSource: i === sourceIdx,
    isSink: i === sinkIdx,
  }));
  const edges: EdgeT[] = EDGES.map((e) => {
    const a = idIndex.get(e.from)!;
    const b = idIndex.get(e.to)!;
    const km = hav(NODES[a].lat, NODES[a].lng, NODES[b].lat, NODES[b].lng);
    const kindBoost =
      e.kind === "expressway" ? 0.6 : e.kind === "highway" ? 0.8 : e.kind === "ring" ? 1.0 : 1.2;
    return {
      id: `${a}-${b}`,
      a: Math.min(a, b),
      b: Math.max(a, b),
      baseLatency: km * 1.2 * kindBoost + 2,
      baseEnergy: km * 0.25 * kindBoost + 0.4,
      reliability: 0.86 + 0.12 * Math.random(),
      capacity: e.capacity,
      conductivity: 0.5 + Math.random() * 0.5,
      flow: 0,
    };
  });
  return { nodes, edges, source: sourceIdx, sink: sinkIdx };
}

// Synthetic 24h congestion time series for a road (5-min buckets).
// Two rush peaks + Gaussian noise. Used to train the LSTM predictor.
export function syntheticCongestionSeries(seed = 1, len = 288) {
  let s = seed;
  const rand = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
  const out: number[] = [];
  for (let i = 0; i < len; i++) {
    const hour = (i * 5) / 60;
    const morning = Math.exp(-((hour - 9) ** 2) / 4);
    const evening = Math.exp(-((hour - 19) ** 2) / 5);
    const base = 25 + 60 * (morning + evening) + 8 * Math.sin(hour / 2);
    const noise = (rand() - 0.5) * 14;
    out.push(Math.max(5, base + noise));
  }
  return out;
}

export const NCR_NODE_LABELS = NODES.map((n, i) => ({ idx: i, label: `${n.name} · ${n.city}` }));
