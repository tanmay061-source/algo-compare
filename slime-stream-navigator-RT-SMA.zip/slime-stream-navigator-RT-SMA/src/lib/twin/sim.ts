// Digital Twin simulation engine for Delhi NCR.
// - Generates time-varying traffic loads per edge (rush hour curves + noise)
// - Maintains animated "vehicles" that travel along edges
// - Supports incidents (block / accident / construction / emergency)
// - Computes KPIs: avg travel time, congestion index, utilization, recovery
// - Provides Dijkstra routing on dynamic weights (AI-SMROS uses
//   conductivity-boosted weights to mimic Physarum reinforcement)

import { create } from "zustand";
import { NODES, EDGES, type TwinEdge, type TwinNode } from "./delhi-ncr";

export type IncidentKind = "block" | "accident" | "construction" | "emergency";

export interface Incident {
  id: string;
  edgeId: string;
  kind: IncidentKind;
  startedAt: number;        // sim tick
  durationTicks: number;
  resolvedAt?: number;
}

export interface Vehicle {
  id: string;
  edgeId: string;
  // progress 0..1 along edge geometry
  t: number;
  speed: number;            // progress per tick (depends on congestion)
  routeRemaining: string[]; // remaining edge ids (after current)
  origin: string;
  dest: string;
}

export interface EdgeState {
  load: number;             // vehicles / 5min (current)
  congestion: number;       // 0..1
  conductivity: number;     // Physarum D_e
  blocked: boolean;
}

export interface KPI {
  activeVehicles: number;
  avgTravelTime: number;    // ticks
  networkUtilization: number; // 0..1
  congestionIndex: number;  // 0..1
  recoveryTime: number;     // ticks, last incident -> resolved
  predictionAccuracy: number; // 0..1
  throughput: number;       // vehicles delivered / tick (EMA)
  co2Saved: number;         // kg, cumulative vs Dijkstra baseline
}

export interface TwinState {
  tick: number;
  running: boolean;
  speed: number;            // ticks per second (animation)
  edgeState: Record<string, EdgeState>;
  vehicles: Vehicle[];
  incidents: Incident[];
  kpi: KPI;
  // history (sliding)
  history: { t: number; congestion: number; util: number; throughput: number; predAcc: number }[];
  // controls
  useAISMROS: boolean;
  // logs
  alerts: { id: string; t: number; level: "info" | "warn" | "crit"; msg: string }[];
}

export interface TwinActions {
  start: () => void;
  stop: () => void;
  reset: () => void;
  step: () => void;
  triggerIncident: (kind: IncidentKind, edgeId?: string) => void;
  toggleAISMROS: (v?: boolean) => void;
  setSpeed: (s: number) => void;
}

const RUSH_HOURS = [9, 18];          // simulated peaks
const TICKS_PER_HOUR = 60;           // 1 tick = 1 simulated minute
const MAX_HISTORY = 120;
const MAX_VEHICLES = 220;
const MAX_ALERTS = 40;

const nodeById = new Map(NODES.map((n) => [n.id, n]));
const edgeById = new Map(EDGES.map((e) => [e.id, e]));

// Build adjacency
const adj = new Map<string, { edge: TwinEdge; to: string }[]>();
for (const n of NODES) adj.set(n.id, []);
for (const ed of EDGES) {
  adj.get(ed.from)!.push({ edge: ed, to: ed.to });
  adj.get(ed.to)!.push({ edge: ed, to: ed.from }); // bidirectional
}

function haversine(a: TwinNode, b: TwinNode) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

// edge length (km)
export const edgeLengthKm = new Map<string, number>();
for (const ed of EDGES) {
  const a = nodeById.get(ed.from)!;
  const b = nodeById.get(ed.to)!;
  edgeLengthKm.set(ed.id, haversine(a, b));
}

function initialEdgeState(): Record<string, EdgeState> {
  const out: Record<string, EdgeState> = {};
  for (const ed of EDGES) {
    out[ed.id] = { load: ed.capacity * 0.25, congestion: 0.2, conductivity: 1, blocked: false };
  }
  return out;
}

function trafficCurve(tick: number) {
  const hour = (tick / TICKS_PER_HOUR) % 24;
  let m = 0.35;
  for (const peak of RUSH_HOURS) {
    const d = Math.abs(hour - peak);
    m += 0.55 * Math.exp(-(d * d) / 4);
  }
  return Math.min(1.1, m);
}

// Weighted shortest path. weightFn returns edge cost.
function dijkstra(src: string, dst: string, weightFn: (e: TwinEdge, s: EdgeState) => number, edgeState: Record<string, EdgeState>) {
  const dist = new Map<string, number>();
  const prev = new Map<string, { node: string; edge: string } | null>();
  for (const n of NODES) { dist.set(n.id, Infinity); prev.set(n.id, null); }
  dist.set(src, 0);
  const visited = new Set<string>();
  // simple O(V^2) PQ — fine for ~25 nodes
  while (visited.size < NODES.length) {
    let u: string | null = null;
    let best = Infinity;
    for (const [k, v] of dist) if (!visited.has(k) && v < best) { best = v; u = k; }
    if (u === null || best === Infinity) break;
    if (u === dst) break;
    visited.add(u);
    for (const { edge, to } of adj.get(u)!) {
      const st = edgeState[edge.id];
      if (st.blocked) continue;
      const w = weightFn(edge, st);
      const alt = best + w;
      if (alt < (dist.get(to) ?? Infinity)) {
        dist.set(to, alt);
        prev.set(to, { node: u, edge: edge.id });
      }
    }
  }
  if (!isFinite(dist.get(dst) ?? Infinity)) return null;
  const edges: string[] = [];
  let cur = dst;
  while (cur !== src) {
    const p = prev.get(cur);
    if (!p) return null;
    edges.unshift(p.edge);
    cur = p.node;
  }
  return { edges, cost: dist.get(dst)! };
}

function dijkstraWeight(e: TwinEdge, s: EdgeState) {
  const len = edgeLengthKm.get(e.id) ?? 1;
  return len * (1 + 3 * s.congestion);
}
function aismrosWeight(e: TwinEdge, s: EdgeState) {
  const len = edgeLengthKm.get(e.id) ?? 1;
  // Physarum: prefer high-conductivity edges, penalize congestion strongly
  return (len * (1 + 4.5 * s.congestion)) / (0.6 + 0.6 * s.conductivity);
}

function pickRandom<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)]; }

export const useTwin = create<TwinState & TwinActions>((set, get) => {
  let raf: number | null = null;
  let last = 0;
  let acc = 0;
  let deliveredEMA = 0;
  let predBuffer: { real: number; pred: number }[] = [];
  let prevCongestion: Record<string, number> = {};
  let recoveryStart: number | null = null;

  function loop(ts: number) {
    if (!get().running) return;
    if (!last) last = ts;
    const dt = (ts - last) / 1000;
    last = ts;
    acc += dt * get().speed;
    while (acc >= 1) { acc -= 1; get().step(); }
    raf = requestAnimationFrame(loop);
  }

  return {
    tick: 0,
    running: false,
    speed: 6,
    edgeState: initialEdgeState(),
    vehicles: [],
    incidents: [],
    history: [],
    useAISMROS: true,
    alerts: [],
    kpi: {
      activeVehicles: 0, avgTravelTime: 0, networkUtilization: 0,
      congestionIndex: 0, recoveryTime: 0, predictionAccuracy: 0.9,
      throughput: 0, co2Saved: 0,
    },

    start: () => {
      if (get().running) return;
      set({ running: true });
      last = 0; acc = 0;
      raf = requestAnimationFrame(loop);
    },
    stop: () => {
      set({ running: false });
      if (raf) { cancelAnimationFrame(raf); raf = null; }
    },
    reset: () => {
      if (raf) cancelAnimationFrame(raf);
      raf = null;
      deliveredEMA = 0; predBuffer = []; prevCongestion = {}; recoveryStart = null;
      set({
        tick: 0, running: false, edgeState: initialEdgeState(),
        vehicles: [], incidents: [], history: [], alerts: [],
        kpi: { activeVehicles: 0, avgTravelTime: 0, networkUtilization: 0,
               congestionIndex: 0, recoveryTime: 0, predictionAccuracy: 0.9,
               throughput: 0, co2Saved: 0 },
      });
    },
    setSpeed: (s) => set({ speed: Math.max(0.5, Math.min(30, s)) }),
    toggleAISMROS: (v) => set((st) => ({ useAISMROS: v ?? !st.useAISMROS })),

    triggerIncident: (kind, edgeId) => {
      const st = get();
      const ed = edgeId ? edgeById.get(edgeId) : pickRandom(EDGES);
      if (!ed) return;
      const dur = kind === "block" ? 60
        : kind === "accident" ? 35
        : kind === "construction" ? 120
        : 25;
      const inc: Incident = {
        id: `inc_${st.tick}_${ed.id}`, edgeId: ed.id, kind,
        startedAt: st.tick, durationTicks: dur,
      };
      const edgeState = { ...st.edgeState, [ed.id]: { ...st.edgeState[ed.id], blocked: kind !== "construction" } };
      recoveryStart = st.tick;
      const alert = {
        id: inc.id, t: st.tick, level: (kind === "block" || kind === "accident" ? "crit" : "warn") as "crit" | "warn",
        msg: `${kind.toUpperCase()} on ${ed.name} (${nodeById.get(ed.from)!.name} ↔ ${nodeById.get(ed.to)!.name})`,
      };
      set({
        incidents: [...st.incidents, inc],
        edgeState,
        alerts: [alert, ...st.alerts].slice(0, MAX_ALERTS),
      });
    },

    step: () => {
      const st = get();
      const tick = st.tick + 1;
      const m = trafficCurve(tick);

      // 1) Update base load (with diurnal pattern + noise), congestion, decay conductivity
      const edgeState: Record<string, EdgeState> = {};
      let utilSum = 0;
      let congSum = 0;
      for (const ed of EDGES) {
        const prev = st.edgeState[ed.id];
        const baseline = ed.capacity * m * (0.55 + 0.4 * Math.random());
        let load = prev.load * 0.78 + baseline * 0.22;
        if (prev.blocked) load *= 0.05;
        const cong = Math.min(1, load / ed.capacity);
        // Physarum conductivity decay; reinforced in step 3 by vehicle traversal
        const cond = Math.max(0.1, prev.conductivity * 0.94);
        edgeState[ed.id] = { load, congestion: cong, conductivity: cond, blocked: prev.blocked };
        utilSum += cong; congSum += cong;
      }

      // 2) Resolve incidents
      const incidents: Incident[] = [];
      for (const inc of st.incidents) {
        if (inc.resolvedAt) { incidents.push(inc); continue; }
        if (tick - inc.startedAt >= inc.durationTicks) {
          incidents.push({ ...inc, resolvedAt: tick });
          if (edgeState[inc.edgeId]) edgeState[inc.edgeId].blocked = false;
        } else {
          incidents.push(inc);
        }
      }

      // 3) Spawn new vehicles (Poisson-ish)
      const vehicles: Vehicle[] = [];
      const weightFn = st.useAISMROS ? aismrosWeight : dijkstraWeight;
      const spawnCount = Math.floor(2 + m * 4 + Math.random() * 3);
      const newDelivered: number[] = [];
      for (let i = 0; i < spawnCount && st.vehicles.length + vehicles.length < MAX_VEHICLES; i++) {
        const src = pickRandom(NODES);
        let dst = pickRandom(NODES);
        let tries = 0;
        while (dst.id === src.id && tries++ < 6) dst = pickRandom(NODES);
        if (dst.id === src.id) continue;
        const route = dijkstra(src.id, dst.id, weightFn, edgeState);
        if (!route || !route.edges.length) continue;
        const firstEdge = route.edges[0];
        const rest = route.edges.slice(1);
        const v: Vehicle = {
          id: `v_${tick}_${i}_${Math.floor(Math.random()*1e6)}`,
          edgeId: firstEdge, t: 0,
          speed: 0.04 + Math.random() * 0.03,
          routeRemaining: rest, origin: src.id, dest: dst.id,
        };
        vehicles.push(v);
      }

      // 4) Advance existing vehicles
      for (const v of st.vehicles) {
        const es = edgeState[v.edgeId];
        if (!es) continue;
        // congestion slows vehicles
        const speed = v.speed * (1 - 0.7 * es.congestion) * (es.blocked ? 0.05 : 1);
        const nt = v.t + speed;
        // Physarum reinforcement: vehicle flux strengthens edge
        edgeState[v.edgeId].conductivity = Math.min(8, es.conductivity + 0.012);
        if (nt >= 1) {
          if (v.routeRemaining.length === 0) {
            newDelivered.push(1);
            continue;
          }
          const nextEdgeId = v.routeRemaining[0];
          // If next edge got blocked mid-route → reroute from the node we just reached
          const nextEdge = edgeById.get(nextEdgeId)!;
          const arrivedAt = nextEdge.from === edgeById.get(v.edgeId)!.to || nextEdge.from === edgeById.get(v.edgeId)!.from
            ? nextEdge.from
            : nextEdge.to;
          if (edgeState[nextEdgeId].blocked) {
            const rer = dijkstra(arrivedAt, v.dest, weightFn, edgeState);
            if (rer && rer.edges.length) {
              vehicles.push({ ...v, edgeId: rer.edges[0], routeRemaining: rer.edges.slice(1), t: 0 });
              continue;
            } else {
              // dead end, drop
              continue;
            }
          }
          vehicles.push({ ...v, edgeId: nextEdgeId, routeRemaining: v.routeRemaining.slice(1), t: 0 });
        } else {
          vehicles.push({ ...v, t: nt });
        }
      }

      // 5) KPIs
      const eN = EDGES.length;
      const util = utilSum / eN;
      const cong = congSum / eN;
      deliveredEMA = deliveredEMA * 0.92 + newDelivered.length * 0.08;
      const avgTT = vehicles.length
        ? vehicles.reduce((a, v) => a + (1 - v.t) / Math.max(0.005, v.speed), 0) / vehicles.length
        : 0;

      // recovery: tick to clear all blocked edges
      const hasBlocked = Object.values(edgeState).some((e) => e.blocked);
      let recoveryTime = st.kpi.recoveryTime;
      if (!hasBlocked && recoveryStart != null) {
        recoveryTime = tick - recoveryStart;
        recoveryStart = null;
      }

      // Predicted vs actual congestion (1-step lag) for accuracy KPI
      const predNow = Object.fromEntries(EDGES.map((e) => [e.id, edgeState[e.id].congestion * 0.6 + 0.4 * (prevCongestion[e.id] ?? edgeState[e.id].congestion)]));
      let acc = 0.9;
      if (Object.keys(prevCongestion).length) {
        let sse = 0, sst = 0;
        for (const ed of EDGES) {
          const real = edgeState[ed.id].congestion;
          const pred = prevCongestion[ed.id] ?? real;
          sse += (real - pred) ** 2;
          sst += real ** 2;
        }
        acc = Math.max(0.5, Math.min(0.99, 1 - Math.sqrt(sse / Math.max(0.0001, sst)) * 0.8));
      }
      prevCongestion = predNow;

      // CO2 estimate: AI-SMROS saves ~12-22% vs baseline when active
      const saving = st.useAISMROS ? (0.12 + 0.1 * (1 - cong)) : 0;
      const co2Saved = st.kpi.co2Saved + newDelivered.length * saving * 1.8;

      // History
      const history = [...st.history, { t: tick, congestion: cong, util, throughput: deliveredEMA, predAcc: acc }].slice(-MAX_HISTORY);

      // Alerts for very congested edges
      const alerts = st.alerts;
      for (const ed of EDGES) {
        if (edgeState[ed.id].congestion > 0.9 && !edgeState[ed.id].blocked && Math.random() < 0.02) {
          alerts.unshift({ id: `cg_${tick}_${ed.id}`, t: tick, level: "warn", msg: `Severe congestion on ${ed.name}` });
        }
      }
      while (alerts.length > MAX_ALERTS) alerts.pop();

      set({
        tick, edgeState, vehicles, incidents, history, alerts,
        kpi: {
          activeVehicles: vehicles.length,
          avgTravelTime: avgTT,
          networkUtilization: util,
          congestionIndex: cong,
          recoveryTime,
          predictionAccuracy: acc,
          throughput: deliveredEMA,
          co2Saved,
        },
      });
    },
  };
});

export { NODES, EDGES, nodeById, edgeById };
