// Tabular Q-learning routing agent over the Delhi NCR graph.
// State  = current node id
// Action = neighbor edge to traverse
// Reward = - (edge cost)  with bonus for reaching sink, penalty for dead-end loops
// Trains via epsilon-greedy episodes; returns greedy path + reward history.

import { adjacency, otherEnd, type EdgeT, type Network } from "@/lib/rtsma/network";

export interface DQNConfig {
  episodes: number;
  alpha: number;       // learning rate
  gamma: number;       // discount
  epsilonStart: number;
  epsilonEnd: number;
  maxStepsPerEp: number;
}

export const defaultDQN: DQNConfig = {
  episodes: 400, alpha: 0.35, gamma: 0.92,
  epsilonStart: 0.9, epsilonEnd: 0.05, maxStepsPerEp: 60,
};

const edgeCost = (e: EdgeT) =>
  e.baseLatency * 0.6 + e.baseEnergy * 1.6 + (1 - e.reliability) * 14;

export interface DQNResult {
  rewardHistory: number[];
  finalPath: number[];
  finalEdges: EdgeT[];
  finalCost: number;
  qTable: Map<string, number>;
}

export function trainQLearning(net: Network, cfg: DQNConfig = defaultDQN): DQNResult {
  const adj = adjacency(net);
  const Q = new Map<string, number>(); // key: `${node}|${edge.id}`
  const qkey = (n: number, e: EdgeT) => `${n}|${e.id}`;
  const rewardHistory: number[] = [];

  for (let ep = 0; ep < cfg.episodes; ep++) {
    const eps =
      cfg.epsilonStart + (cfg.epsilonEnd - cfg.epsilonStart) * (ep / cfg.episodes);
    let s = net.source;
    let totalR = 0;
    const visited = new Set<number>([s]);
    for (let t = 0; t < cfg.maxStepsPerEp; t++) {
      const acts = (adj.get(s) ?? []).filter((e) => net.nodes[otherEnd(e, s)].alive);
      if (!acts.length) { totalR -= 30; break; }
      let chosen: EdgeT;
      if (Math.random() < eps) {
        chosen = acts[Math.floor(Math.random() * acts.length)];
      } else {
        let best = -Infinity, pick = acts[0];
        for (const a of acts) {
          const v = Q.get(qkey(s, a)) ?? 0;
          if (v > best) { best = v; pick = a; }
        }
        chosen = pick;
      }
      const sNext = otherEnd(chosen, s);
      const loopPenalty = visited.has(sNext) ? 4 : 0;
      const arrived = sNext === net.sink;
      const r = -edgeCost(chosen) - loopPenalty + (arrived ? 60 : 0);
      totalR += r;
      // Bellman update
      const nextActs = (adj.get(sNext) ?? []).filter((e) => net.nodes[otherEnd(e, sNext)].alive);
      const maxNext = nextActs.length
        ? Math.max(...nextActs.map((a) => Q.get(qkey(sNext, a)) ?? 0))
        : 0;
      const k = qkey(s, chosen);
      const old = Q.get(k) ?? 0;
      Q.set(k, old + cfg.alpha * (r + cfg.gamma * maxNext - old));
      if (arrived) break;
      s = sNext;
      visited.add(s);
    }
    rewardHistory.push(totalR);
  }

  // Extract greedy path
  const path: number[] = [net.source];
  const edges: EdgeT[] = [];
  const seen = new Set<number>([net.source]);
  let cur = net.source;
  let cost = 0;
  for (let i = 0; i < cfg.maxStepsPerEp; i++) {
    const acts = (adj.get(cur) ?? []).filter(
      (e) => net.nodes[otherEnd(e, cur)].alive && !seen.has(otherEnd(e, cur)),
    );
    if (!acts.length) break;
    let best = -Infinity, pick = acts[0];
    for (const a of acts) {
      const v = Q.get(qkey(cur, a)) ?? 0;
      if (v > best) { best = v; pick = a; }
    }
    edges.push(pick);
    cost += edgeCost(pick);
    cur = otherEnd(pick, cur);
    path.push(cur);
    seen.add(cur);
    if (cur === net.sink) break;
  }
  return { rewardHistory, finalPath: path, finalEdges: edges, finalCost: cost, qTable: Q };
}
