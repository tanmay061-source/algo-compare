import { Fragment, useEffect, useRef } from "react";
import gsap from "gsap";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar,
  ScatterChart, Scatter, AreaChart, Area, Legend,
} from "recharts";
import { useSim, useDatasetAnalysis } from "@/lib/rtsma/store";

const palette = {
  cyan: "oklch(0.82 0.18 195)",
  magenta: "oklch(0.7 0.25 325)",
  amber: "oklch(0.83 0.17 75)",
  lime: "oklch(0.85 0.2 130)",
  grid: "oklch(1 0 0 / 0.06)",
  axis: "oklch(0.7 0.03 250)",
};

function Card({ title, children, className = "" }: { title: string; children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) gsap.from(ref.current, { y: 14, opacity: 0, duration: 0.5, ease: "power2.out" });
  }, []);
  return (
    <div ref={ref} className={`glass rounded-xl p-3 flex flex-col min-w-0 ${className}`}>
      <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-2">{title}</div>
      <div className="flex-1 min-h-0 min-w-0 w-full relative">{children}</div>
    </div>
  );
}

export function ChartsPanel() {
  const { stats, corr } = useDatasetAnalysis();
  const dataset = useSim((s) => s.dataset);
  const history = useSim((s) => s.history);
  const energyHistory = useSim((s) => s.energyHistory);

  // Flow distribution (histogram bins)
  const bins = 12;
  const flows = dataset.map((r) => r.flow_rate);
  const min = Math.min(...flows), max = Math.max(...flows);
  const step = (max - min) / bins;
  const flowHist = Array.from({ length: bins }, (_, i) => {
    const lo = min + i * step, hi = lo + step;
    const count = flows.filter((f) => f >= lo && f < hi).length;
    return { bin: `${lo.toFixed(0)}`, count };
  });

  const lats = dataset.map((r) => r.latency);
  const lmin = Math.min(...lats), lmax = Math.max(...lats), ls = (lmax - lmin) / bins;
  const latHist = Array.from({ length: bins }, (_, i) => {
    const lo = lmin + i * ls, hi = lo + ls;
    return { bin: `${lo.toFixed(0)}`, count: lats.filter((f) => f >= lo && f < hi).length };
  });

  const scatter = dataset.filter((_, i) => i % 4 === 0).map((r) => ({ x: r.flow_rate, y: r.packet_size }));
  const attackBar = [
    { name: "Normal", value: dataset.filter((r) => r.attack_flag === 0).length },
    { name: "Attack", value: dataset.filter((r) => r.attack_flag === 1).length },
  ];

  const corrLabels = ["flow", "latency", "energy", "attack"];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 h-full overflow-auto scrollbar-thin pr-1">
      <Card title="Comparison · Latency over time" className="lg:col-span-3 h-56">
        <ResponsiveContainer>
          <LineChart data={history}>
            <CartesianGrid stroke={palette.grid} />
            <XAxis dataKey="t" stroke={palette.axis} fontSize={10} />
            <YAxis stroke={palette.axis} fontSize={10} />
            <Tooltip contentStyle={{ background: "oklch(0.18 0.04 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 8 }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Line type="monotone" dataKey="rtsma" stroke={palette.cyan} dot={false} strokeWidth={2.4} name="RT-SMA" />
            <Line type="monotone" dataKey="aco" stroke={palette.magenta} dot={false} strokeWidth={1.8} name="ACO" />
            <Line type="monotone" dataKey="pso" stroke={palette.amber} dot={false} strokeWidth={1.8} name="PSO" />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Energy over time (lower is better)" className="lg:col-span-2 h-44">
        <ResponsiveContainer>
          <AreaChart data={energyHistory}>
            <defs>
              <linearGradient id="rtg" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor={palette.cyan} stopOpacity={0.7} />
                <stop offset="100%" stopColor={palette.cyan} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke={palette.grid} />
            <XAxis dataKey="t" stroke={palette.axis} fontSize={10} />
            <YAxis stroke={palette.axis} fontSize={10} />
            <Tooltip contentStyle={{ background: "oklch(0.18 0.04 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 8 }} />
            <Area type="monotone" dataKey="rtsma" stroke={palette.cyan} fill="url(#rtg)" name="RT-SMA" />
            <Area type="monotone" dataKey="aco" stroke={palette.magenta} fill="transparent" name="ACO" />
            <Area type="monotone" dataKey="pso" stroke={palette.amber} fill="transparent" name="PSO" />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Attack vs Normal" className="h-44">
        <ResponsiveContainer>
          <BarChart data={attackBar}>
            <CartesianGrid stroke={palette.grid} />
            <XAxis dataKey="name" stroke={palette.axis} fontSize={10} />
            <YAxis stroke={palette.axis} fontSize={10} />
            <Tooltip contentStyle={{ background: "oklch(0.18 0.04 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 8 }} />
            <Bar dataKey="value" fill={palette.magenta} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Flow distribution" className="h-44">
        <ResponsiveContainer>
          <BarChart data={flowHist}>
            <CartesianGrid stroke={palette.grid} />
            <XAxis dataKey="bin" stroke={palette.axis} fontSize={9} />
            <YAxis stroke={palette.axis} fontSize={10} />
            <Tooltip contentStyle={{ background: "oklch(0.18 0.04 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 8 }} />
            <Bar dataKey="count" fill={palette.cyan} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Latency distribution" className="h-44">
        <ResponsiveContainer>
          <BarChart data={latHist}>
            <CartesianGrid stroke={palette.grid} />
            <XAxis dataKey="bin" stroke={palette.axis} fontSize={9} />
            <YAxis stroke={palette.axis} fontSize={10} />
            <Tooltip contentStyle={{ background: "oklch(0.18 0.04 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 8 }} />
            <Bar dataKey="count" fill={palette.amber} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Energy vs Flow (scatter)" className="h-44">
        <ResponsiveContainer>
          <ScatterChart>
            <CartesianGrid stroke={palette.grid} />
            <XAxis type="number" dataKey="x" name="flow" stroke={palette.axis} fontSize={10} />
            <YAxis type="number" dataKey="y" name="packet" stroke={palette.axis} fontSize={10} />
            <Tooltip contentStyle={{ background: "oklch(0.18 0.04 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 8 }} cursor={{ stroke: palette.grid }} />
            <Scatter data={scatter} fill={palette.lime} />
          </ScatterChart>
        </ResponsiveContainer>
      </Card>

      <Card title={`Correlation matrix · n=${stats.n}`} className="h-44">
        <div className="grid grid-cols-5 gap-1 text-[10px] h-full">
          <div />
          {corrLabels.map((l) => <div key={l} className="text-center text-muted-foreground">{l}</div>)}
          {corr.map((row, i) => (
            <Fragment key={`row-${i}`}>
              <div className="text-muted-foreground">{corrLabels[i]}</div>
              {row.map((v, j) => {
                const a = Math.abs(v);
                const bg = v >= 0
                  ? `oklch(0.82 0.18 195 / ${0.15 + 0.7 * a})`
                  : `oklch(0.7 0.25 325 / ${0.15 + 0.7 * a})`;
                return (
                  <div key={`${i}-${j}`} className="rounded grid place-items-center font-mono text-foreground/90"
                    style={{ background: bg }}>
                    {v.toFixed(2)}
                  </div>
                );
              })}
            </Fragment>
          ))}
        </div>
      </Card>
    </div>
  );
}
