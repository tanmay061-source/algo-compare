import { useEffect, useRef } from "react";
import * as THREE from "three";
import gsap from "gsap";
import { useSim } from "@/lib/rtsma/store";

export function NetworkScene() {
  const mountRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef<{
    renderer?: THREE.WebGLRenderer;
    scene?: THREE.Scene;
    camera?: THREE.PerspectiveCamera;
    nodeMeshes: Map<number, THREE.Mesh>;
    edgeLines: Map<string, THREE.Line>;
    particles: Map<string, THREE.Mesh[]>;
    raf?: number;
  }>({ nodeMeshes: new Map(), edgeLines: new Map(), particles: new Map() });

  // Initial setup
  useEffect(() => {
    const mount = mountRef.current!;
    const w = mount.clientWidth, h = mount.clientHeight;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(55, w / h, 0.1, 100);
    camera.position.set(0, 0, 20);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    renderer.setSize(w, h);
    mount.appendChild(renderer.domElement);

    const ambient = new THREE.AmbientLight(0x88aaff, 0.4);
    const point = new THREE.PointLight(0x4dd0e1, 2, 50);
    point.position.set(8, 8, 8);
    const point2 = new THREE.PointLight(0xff4ddc, 1.4, 50);
    point2.position.set(-8, -6, 4);
    scene.add(ambient, point, point2);

    stateRef.current.renderer = renderer;
    stateRef.current.scene = scene;
    stateRef.current.camera = camera;

    let rotY = 0;
    const animate = () => {
      rotY += 0.0018;
      scene.rotation.y = rotY;
      renderer.render(scene, camera);
      stateRef.current.raf = requestAnimationFrame(animate);
    };
    animate();

    const onResize = () => {
      const W = mount.clientWidth, H = mount.clientHeight;
      camera.aspect = W / H; camera.updateProjectionMatrix(); renderer.setSize(W, H);
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (stateRef.current.raf) cancelAnimationFrame(stateRef.current.raf);
      renderer.dispose();
      mount.removeChild(renderer.domElement);
    };
  }, []);

  // Sync scene to store
  useEffect(() => {
    const sync = (s: ReturnType<typeof useSim.getState>) => {
      const sc = stateRef.current.scene; if (!sc) return;
      const { network, rtsma } = s;
      void rtsma;
      // nodes
      for (const n of network.nodes) {
        let mesh = stateRef.current.nodeMeshes.get(n.id);
        if (!mesh) {
          const geom = new THREE.SphereGeometry(n.isSource || n.isSink ? 0.5 : 0.32, 24, 24);
          const mat = new THREE.MeshStandardMaterial({
            color: n.isSource ? 0x6affc7 : n.isSink ? 0xffb74d : 0x4dd0e1,
            emissive: n.isSource ? 0x1a8d6a : n.isSink ? 0x8a5a1a : 0x0d4d56,
            emissiveIntensity: 1.1, roughness: 0.3, metalness: 0.6,
          });
          mesh = new THREE.Mesh(geom, mat);
          mesh.position.set(n.x, n.y, n.z);
          sc.add(mesh);
          stateRef.current.nodeMeshes.set(n.id, mesh);
          gsap.from(mesh.scale, { x: 0, y: 0, z: 0, duration: 0.6, ease: "back.out(1.8)" });
        }
        const targetOpacity = n.alive ? 1 : 0.15;
        const mat = mesh.material as THREE.MeshStandardMaterial;
        mat.transparent = true;
        gsap.to(mat, { opacity: targetOpacity, emissiveIntensity: n.alive ? 1.1 : 0.1, duration: 0.6 });
        if (!n.alive) gsap.to(mesh.scale, { x: 0.6, y: 0.6, z: 0.6, duration: 0.6 });
      }
      // edges
      const onPath = new Set(rtsma.result?.edges.map((e) => e.id) ?? []);
      for (const e of network.edges) {
        let line = stateRef.current.edgeLines.get(e.id);
        const a = network.nodes[e.a], b = network.nodes[e.b];
        const isOnPath = onPath.has(e.id);
        const baseColor = isOnPath ? 0x6affc7 : 0x4dd0e1;
        const opacity = network.nodes[e.a].alive && network.nodes[e.b].alive
          ? Math.max(0.08, Math.min(0.95, 0.15 + e.conductivity * 0.5)) : 0.04;
        if (!line) {
          const geom = new THREE.BufferGeometry().setFromPoints([
            new THREE.Vector3(a.x, a.y, a.z), new THREE.Vector3(b.x, b.y, b.z),
          ]);
          const mat = new THREE.LineBasicMaterial({ color: baseColor, transparent: true, opacity });
          line = new THREE.Line(geom, mat);
          sc.add(line);
          stateRef.current.edgeLines.set(e.id, line);
        }
        const mat = line.material as THREE.LineBasicMaterial;
        gsap.to(mat, { opacity, duration: 0.4 });
        mat.color.setHex(baseColor);

        // Flow particles along selected RT-SMA path
        const existing = stateRef.current.particles.get(e.id) ?? [];
        if (isOnPath && existing.length === 0) {
          const particles: THREE.Mesh[] = [];
          for (let i = 0; i < 3; i++) {
            const g = new THREE.SphereGeometry(0.12, 12, 12);
            const m = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x6affc7, emissiveIntensity: 2 });
            const p = new THREE.Mesh(g, m);
            sc.add(p);
            particles.push(p);
            const tween = { t: i / 3 };
            gsap.to(tween, {
              t: tween.t + 1, duration: 1.6, repeat: -1, ease: "none",
              onUpdate: () => {
                const tt = tween.t % 1;
                p.position.set(a.x + (b.x - a.x) * tt, a.y + (b.y - a.y) * tt, a.z + (b.z - a.z) * tt);
              },
            });
          }
          stateRef.current.particles.set(e.id, particles);
        } else if (!isOnPath && existing.length > 0) {
          for (const p of existing) { sc.remove(p); (p.material as THREE.Material).dispose(); p.geometry.dispose(); }
          stateRef.current.particles.set(e.id, []);
        }
      }
    };
    sync(useSim.getState());
    return useSim.subscribe(sync);
  }, []);

  return <div ref={mountRef} className="absolute inset-0" />;
}
