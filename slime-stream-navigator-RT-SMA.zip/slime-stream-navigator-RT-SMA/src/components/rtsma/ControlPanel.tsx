import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { useSim } from "@/lib/rtsma/store";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw, Zap, Brain, Activity, Upload, Download, Cpu } from "lucide-react";
import { exportRunReport, uploadDatasetFile } from "@/lib/rtsma/report";
import { toast } from "sonner";

function Row({ label, value, children }: { label: string; value: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex justify-between text-[11px] mb-1.5">
        <span className="text-muted-foreground uppercase tracking-wider">{label}</span>
        <span className="font-mono text-foreground">{value}</span>
      </div>
      {children}
    </div>
  );
}

export function ControlPanel() {
  const s = useSim();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!s.running) return;
    const id = setInterval(() => useSim.getState().step(), 800);
    return () => clearInterval(id);
  }, [s.running]);

  // Initial step so charts populate
  useEffect(() => { useSim.getState().step(); useSim.getState().step(); }, []);

  useEffect(() => {
    gsap.from(".ctl-section", { y: 12, opacity: 0, stagger: 0.06, duration: 0.5, ease: "power2.out" });
  }, []);

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (!f) return;
    try {
      setBusy(true);
      const rep = await uploadDatasetFile(f);
      const d = rep.detected;
      const map = `flow=${d.flow ?? "—"} · lat=${d.latency ?? "—"} · erg=${d.energy ?? "—"} · atk=${d.attack ?? "—"}`;
      toast.success(`Loaded ${rep.rows.length}/${rep.stats.totalRows} rows`, { description: map });
      rep.warnings.slice(0, 3).forEach((w) => toast.warning(w));
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false); if (fileRef.current) fileRef.current.value = "";
    }
  };

  const onTrainLSTM = async () => {
    setBusy(true);
    toast.message("Training LSTM…", { description: "TF.js LSTM(8) → Dense(1)" });
    await s.trainLSTM();
    setBusy(false);
    toast.success(`LSTM trained · loss=${s.lstmLoss?.toFixed(4) ?? "—"}`);
  };

  return (
    <div className="h-full flex flex-col gap-4 overflow-auto scrollbar-thin pr-1">
      <div className="ctl-section">
        <h1 className="text-lg font-semibold tracking-tight">RT-SMA</h1>
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          Real-Time Slime Mold Multi-Objective Optimization for dynamic IoT networks.
        </p>
      </div>

      <div className="ctl-section grid grid-cols-2 gap-2">
        <Button onClick={s.toggleRunning} className="bg-primary text-primary-foreground hover:bg-primary/90 glow-cyan">
          {s.running ? <><Pause className="w-4 h-4 mr-1" />Pause</> : <><Play className="w-4 h-4 mr-1" />Run</>}
        </Button>
        <Button variant="secondary" onClick={s.reset}>
          <RotateCcw className="w-4 h-4 mr-1" />Reset
        </Button>
        <Button variant="secondary" onClick={s.failRandomNode} className="col-span-2">
          <Zap className="w-4 h-4 mr-1" />Trigger node failure
        </Button>
      </div>

      <div className="ctl-section grid grid-cols-2 gap-2">
        <input ref={fileRef} type="file" accept=".csv,.tsv,.txt,.xlsx,.xls" className="hidden" onChange={onUpload} />
        <Button variant="secondary" onClick={() => fileRef.current?.click()} disabled={busy}>
          <Upload className="w-4 h-4 mr-1" />Upload dataset
        </Button>
        <Button variant="secondary" onClick={exportRunReport}>
          <Download className="w-4 h-4 mr-1" />Export report
        </Button>
      </div>

      <div className="ctl-section glass rounded-xl p-3 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm"><Brain className="w-4 h-4 text-primary" />LSTM prediction</div>
          <Switch checked={s.useAI} onCheckedChange={s.toggleAI} />
        </div>
        <div className="text-[11px] text-muted-foreground flex justify-between">
          <span>Predicted flow</span>
          <span className="font-mono text-primary">{s.predictedFlow.toFixed(1)} pkt/s</span>
        </div>
        <div className="text-[11px] text-muted-foreground flex justify-between">
          <span>Model status</span>
          <span className={`font-mono ${s.lstmReady ? "text-[oklch(0.85_0.2_130)]" : "text-muted-foreground"}`}>
            {s.lstmTraining ? "training…" : s.lstmReady ? `trained · loss ${s.lstmLoss?.toFixed(4)}` : "untrained (EMA)"}
          </span>
        </div>
        <Button size="sm" variant="secondary" onClick={onTrainLSTM} disabled={s.lstmTraining || busy} className="w-full">
          <Cpu className="w-3.5 h-3.5 mr-1" />Train TF.js LSTM
        </Button>
      </div>

      <div className="ctl-section glass rounded-xl p-3 space-y-4">
        <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground flex items-center gap-2">
          <Activity className="w-3.5 h-3.5" /> RT-SMA params
        </div>
        <Row label="α (reinforcement)" value={s.params.alpha.toFixed(2)}>
          <Slider value={[s.params.alpha]} min={0.1} max={1.5} step={0.05}
            onValueChange={(v) => s.setParam("alpha", v[0])} />
        </Row>
        <Row label="β (decay)" value={s.params.beta.toFixed(2)}>
          <Slider value={[s.params.beta]} min={0.05} max={0.6} step={0.01}
            onValueChange={(v) => s.setParam("beta", v[0])} />
        </Row>
        <Row label="w₁ latency" value={s.params.w1.toFixed(2)}>
          <Slider value={[s.params.w1]} min={0} max={1} step={0.05}
            onValueChange={(v) => s.setParam("w1", v[0])} />
        </Row>
        <Row label="w₂ energy" value={s.params.w2.toFixed(2)}>
          <Slider value={[s.params.w2]} min={0} max={1} step={0.05}
            onValueChange={(v) => s.setParam("w2", v[0])} />
        </Row>
        <Row label="w₃ reliability" value={s.params.w3.toFixed(2)}>
          <Slider value={[s.params.w3]} min={0} max={1} step={0.05}
            onValueChange={(v) => s.setParam("w3", v[0])} />
        </Row>
      </div>

      <div className="ctl-section glass rounded-xl p-3 space-y-2">
        <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Live metrics</div>
        <MetricRow name="RT-SMA" m={s.rtsma.metrics} accent="oklch(0.82 0.18 195)" highlight />
        <MetricRow name="ACO" m={s.aco.metrics} accent="oklch(0.7 0.25 325)" />
        <MetricRow name="PSO" m={s.pso.metrics} accent="oklch(0.83 0.17 75)" />
      </div>
    </div>
  );
}

function MetricRow({ name, m, accent, highlight }: { name: string; m: any; accent: string; highlight?: boolean }) {
  return (
    <div className={`rounded-lg px-2.5 py-2 ${highlight ? "bg-primary/10 border border-primary/30" : "bg-foreground/5"}`}>
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="font-semibold" style={{ color: accent }}>{name}</span>
        <span className="font-mono text-[10px] text-muted-foreground">
          {m ? `${m.convergenceMs.toFixed(1)}ms` : "—"}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-1 text-[10px] font-mono">
        <Stat label="lat" v={m?.avgLatency} />
        <Stat label="erg" v={m?.energy} />
        <Stat label="rel" v={m?.reliability} pct />
      </div>
    </div>
  );
}
function Stat({ label, v, pct }: { label: string; v?: number; pct?: boolean }) {
  return (
    <div className="text-center">
      <div className="text-muted-foreground">{label}</div>
      <div className="text-foreground">{v == null ? "—" : pct ? `${(v * 100).toFixed(1)}%` : v.toFixed(2)}</div>
    </div>
  );
}
