// Unused: shadcn chart wrapper is incompatible with installed Recharts v3.
// We use Recharts components directly throughout the app.
export {};
