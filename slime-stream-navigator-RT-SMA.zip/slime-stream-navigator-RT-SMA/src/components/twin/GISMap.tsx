// Leaflet GIS map. Client-only — Leaflet is dynamically imported after mount
// (it touches `window` at module load) and then drives the live twin state.
import { useEffect, useMemo, useRef, useState } from "react";
import type * as LeafletNS from "leaflet";
import { useTwin, NODES, EDGES, nodeById, edgeById } from "@/lib/twin/sim";
import type { TwinNode } from "@/lib/twin/delhi-ncr";

const NODE_COLORS: Record<TwinNode["kind"], string> = {
  intersection: "#22d3ee",
  metro: "#a78bfa",
  bus_terminal: "#fbbf24",
  highway_junction: "#34d399",
  logistics: "#f472b6",
  emergency: "#f87171",
};

function congestionColor(c: number, blocked: boolean) {
  if (blocked) return "#ef4444";
  if (c < 0.45) return "#22c55e";
  if (c < 0.75) return "#eab308";
  return "#ef4444";
}

export function GISMap() {
  const [L, setL] = useState<typeof LeafletNS | null>(null);
  useEffect(() => {
    let mounted = true;
    (async () => {
      // load CSS + JS only on client
      await import("leaflet/dist/leaflet.css");
      const mod = await import("leaflet");
      if (mounted) setL(mod.default ?? (mod as unknown as typeof LeafletNS));
    })();
    return () => { mounted = false; };
  }, []);
  if (!L) {
    return <div className="w-full h-full grid place-items-center text-xs text-muted-foreground">Loading GIS map…</div>;
  }
  return <LeafletInner L={L} />;
}

function LeafletInner({ L }: { L: typeof LeafletNS }) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<LeafletNS.Map | null>(null);
  const edgeLayers = useRef<Map<string, LeafletNS.Polyline>>(new Map());
  const vehicleLayer = useRef<LeafletNS.LayerGroup | null>(null);
  const [selected, setSelected] = useState<{ kind: "node" | "edge"; id: string } | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapObj.current) return;
    const map = L.map(mapRef.current, {
      center: [28.55, 77.22], zoom: 10, zoomControl: true,
      preferCanvas: true, attributionControl: false,
    });
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19, subdomains: "abcd",
    }).addTo(map);
    L.control.attribution({ position: "bottomleft", prefix: false })
      .addAttribution("© OpenStreetMap · CARTO").addTo(map);

    for (const ed of EDGES) {
      const a = nodeById.get(ed.from)!;
      const b = nodeById.get(ed.to)!;
      const line = L.polyline([[a.lat, a.lng], [b.lat, b.lng]], {
        color: "#22c55e", weight: 4, opacity: 0.85, lineCap: "round",
      });
      line.on("click", () => setSelected({ kind: "edge", id: ed.id }));
      line.bindTooltip(ed.name, { sticky: true, direction: "top", className: "twin-tt" });
      line.addTo(map);
      edgeLayers.current.set(ed.id, line);
    }
    for (const n of NODES) {
      const c = NODE_COLORS[n.kind];
      const marker = L.circleMarker([n.lat, n.lng], {
        radius: n.kind === "emergency" || n.kind === "highway_junction" ? 7 : 6,
        color: "#0b1020", weight: 1.5, fillColor: c, fillOpacity: 0.95,
      });
      marker.bindTooltip(`<b>${n.name}</b><br/>${n.kind.replace("_", " ")} · ${n.city}`,
        { direction: "top", offset: [0, -6], className: "twin-tt" });
      marker.on("click", () => setSelected({ kind: "node", id: n.id }));
      marker.addTo(map);
    }
    vehicleLayer.current = L.layerGroup().addTo(map);
    mapObj.current = map;
    return () => { map.remove(); mapObj.current = null; edgeLayers.current.clear(); };
  }, [L]);

  useEffect(() => {
    if (!mapObj.current) return;
    const sync = (s: ReturnType<typeof useTwin.getState>) => {
      for (const [id, line] of edgeLayers.current) {
        const st = s.edgeState[id];
        if (!st) continue;
        const color = congestionColor(st.congestion, st.blocked);
        const weight = 2 + Math.min(6, st.conductivity * 1.2);
        line.setStyle({ color, weight, opacity: st.blocked ? 0.4 : 0.9, dashArray: st.blocked ? "6 6" : undefined });
      }
      const vl = vehicleLayer.current!;
      vl.clearLayers();
      for (const v of s.vehicles) {
        const ed = edgeById.get(v.edgeId);
        if (!ed) continue;
        const a = nodeById.get(ed.from)!;
        const b = nodeById.get(ed.to)!;
        const lat = a.lat + (b.lat - a.lat) * v.t;
        const lng = a.lng + (b.lng - a.lng) * v.t;
        const cong = s.edgeState[v.edgeId]?.congestion ?? 0;
        const fill = cong > 0.75 ? "#fca5a5" : cong > 0.45 ? "#fde68a" : "#bbf7d0";
        L.circleMarker([lat, lng], {
          radius: 2.5, color: "#000", weight: 0, fillColor: fill, fillOpacity: 0.9,
        }).addTo(vl);
      }
    };
    sync(useTwin.getState());
    return useTwin.subscribe(sync);
  }, [L]);

  const detail = useMemo(() => {
    if (!selected) return null;
    const s = useTwin.getState();
    if (selected.kind === "node") {
      const n = nodeById.get(selected.id)!;
      return { title: n.name, lines: [`${n.kind.replace("_", " ")} · ${n.city}`, `${n.lat.toFixed(4)}, ${n.lng.toFixed(4)}`] };
    }
    const e = edgeById.get(selected.id)!;
    const st = s.edgeState[e.id];
    return {
      title: e.name,
      lines: [
        `${nodeById.get(e.from)!.name} ↔ ${nodeById.get(e.to)!.name}`,
        `${e.kind} · capacity ${e.capacity}/5min`,
        `Load ${st?.load.toFixed(0)} · Congestion ${(st!.congestion * 100).toFixed(0)}%`,
        `Conductivity ${st?.conductivity.toFixed(2)} ${st?.blocked ? "· BLOCKED" : ""}`,
      ],
    };
  }, [selected]);

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full rounded-xl overflow-hidden" />
      <style>{`
        .leaflet-container { background: #0a0f1c; font-family: var(--font-display); }
        .twin-tt { background: rgba(10,15,28,0.92) !important; color: #e6f1ff !important; border: 1px solid rgba(255,255,255,0.1) !important; font-size: 11px; }
        .twin-tt::before { display: none; }
        .leaflet-control-zoom a { background: rgba(10,15,28,0.85) !important; color: #e6f1ff !important; border-color: rgba(255,255,255,0.1) !important; }
        .leaflet-control-attribution { background: rgba(10,15,28,0.6) !important; color: #94a3b8 !important; font-size: 10px; }
      `}</style>

      <div className="absolute top-3 left-3 glass-strong rounded-lg px-3 py-2 text-[10px] flex gap-3 pointer-events-auto z-[400]">
        <Legend c="#22c55e" l="Free flow" />
        <Legend c="#eab308" l="Moderate" />
        <Legend c="#ef4444" l="Heavy / blocked" />
      </div>

      {detail && (
        <div className="absolute bottom-3 left-3 right-3 sm:right-auto glass-strong rounded-xl px-4 py-3 max-w-md pointer-events-auto z-[400]">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold text-gradient">{detail.title}</div>
            <button onClick={() => setSelected(null)} className="text-muted-foreground hover:text-foreground text-xs">✕</button>
          </div>
          <div className="mt-1 text-[11px] font-mono text-muted-foreground space-y-0.5">
            {detail.lines.map((l) => <div key={l}>{l}</div>)}
          </div>
        </div>
      )}
    </div>
  );
}

function Legend({ c, l }: { c: string; l: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-2.5 h-1 rounded-full" style={{ background: c, boxShadow: `0 0 6px ${c}` }} />
      <span className="text-muted-foreground">{l}</span>
    </div>
  );
}
