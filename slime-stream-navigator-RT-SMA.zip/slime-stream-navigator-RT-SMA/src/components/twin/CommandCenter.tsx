import { useEffect, useRef } from "react";
import { useTwin, EDGES } from "@/lib/twin/sim";
import gsap from "gsap";
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid,
  LineChart, Line,
} from "recharts";

export function KPIGrid() {
  const kpi = useTwin((s) => s.kpi);
  const tick = useTwin((s) => s.tick);
  const items = [
    { k: "Active Vehicles", v: kpi.activeVehicles.toString(), unit: "", c: "var(--cyan)" },
    { k: "Avg Travel Time", v: kpi.avgTravelTime.toFixed(1), unit: "min", c: "var(--amber)" },
    { k: "Network Utilization", v: (kpi.networkUtilization * 100).toFixed(0), unit: "%", c: "var(--lime)" },
    { k: "Congestion Index", v: (kpi.congestionIndex * 100).toFixed(0), unit: "%", c: kpi.congestionIndex > 0.7 ? "var(--destructive)" : "var(--amber)" },
    { k: "Recovery Time", v: kpi.recoveryTime ? kpi.recoveryTime.toString() : "—", unit: kpi.recoveryTime ? "tk" : "", c: "var(--magenta)" },
    { k: "Prediction Acc.", v: (kpi.predictionAccuracy * 100).toFixed(1), unit: "%", c: "var(--cyan)" },
    { k: "Throughput", v: kpi.throughput.toFixed(2), unit: "/tk", c: "var(--lime)" },
    { k: "CO₂ Saved", v: kpi.co2Saved.toFixed(1), unit: "kg", c: "var(--magenta)" },
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
      {items.map((it) => <KPICard key={it.k} {...it} tick={tick} />)}
    </div>
  );
}

function KPICard({ k, v, unit, c, tick }: { k: string; v: string; unit: string; c: string; tick: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    gsap.fromTo(ref.current, { scale: 1 }, { scale: 1.04, duration: 0.12, yoyo: true, repeat: 1, ease: "power1.out" });
  }, [v, tick]);
  return (
    <div className="glass rounded-xl p-3 relative overflow-hidden">
      <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground">{k}</div>
      <div ref={ref} className="mt-1 flex items-baseline gap-1">
        <span className="text-xl font-mono font-semibold" style={{ color: c }}>{v}</span>
        <span className="text-[10px] text-muted-foreground">{unit}</span>
      </div>
      <div className="absolute inset-x-0 bottom-0 h-0.5" style={{ background: c, opacity: 0.6 }} />
    </div>
  );
}

export function NetworkStatus() {
  const edgeState = useTwin((s) => s.edgeState);
  const total = EDGES.length;
  let free = 0, mod = 0, hvy = 0, blk = 0;
  for (const e of EDGES) {
    const s = edgeState[e.id];
    if (s.blocked) blk++;
    else if (s.congestion < 0.45) free++;
    else if (s.congestion < 0.75) mod++;
    else hvy++;
  }
  const pct = (n: number) => ((n / total) * 100).toFixed(0);
  return (
    <div className="glass rounded-xl p-3">
      <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground mb-2">Network Health</div>
      <div className="flex h-2 rounded-full overflow-hidden">
        <span style={{ width: `${pct(free)}%`, background: "#22c55e" }} />
        <span style={{ width: `${pct(mod)}%`, background: "#eab308" }} />
        <span style={{ width: `${pct(hvy)}%`, background: "#ef4444" }} />
        <span style={{ width: `${pct(blk)}%`, background: "#7f1d1d" }} />
      </div>
      <div className="mt-2 grid grid-cols-4 gap-1 text-[10px] font-mono">
        <Stat color="#22c55e" label="Free" n={free} />
        <Stat color="#eab308" label="Mod" n={mod} />
        <Stat color="#ef4444" label="Heavy" n={hvy} />
        <Stat color="#7f1d1d" label="Block" n={blk} />
      </div>
    </div>
  );
}
function Stat({ color, label, n }: { color: string; label: string; n: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
      <span className="text-muted-foreground">{label}</span>
      <span className="ml-auto text-foreground">{n}</span>
    </div>
  );
}

export function TwinCharts() {
  const history = useTwin((s) => s.history);
  return (
    <div className="grid md:grid-cols-2 gap-2.5">
      <div className="glass rounded-xl p-3 min-w-0">
        <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground mb-1">Congestion · Utilization</div>
        <div className="h-40 min-w-0 relative">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={history} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <defs>
                <linearGradient id="gA" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.5}/>
                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="gB" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.4}/>
                  <stop offset="100%" stopColor="#22d3ee" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="t" tick={{ fontSize: 9, fill: "#94a3b8" }} />
              <YAxis tick={{ fontSize: 9, fill: "#94a3b8" }} domain={[0, 1]} />
              <Tooltip contentStyle={{ background: "rgba(10,15,28,0.95)", border: "1px solid rgba(255,255,255,0.1)", fontSize: 11 }} />
              <Area type="monotone" dataKey="congestion" stroke="#ef4444" fill="url(#gA)" strokeWidth={1.5} />
              <Area type="monotone" dataKey="util" stroke="#22d3ee" fill="url(#gB)" strokeWidth={1.5} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="glass rounded-xl p-3 min-w-0">
        <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground mb-1">Throughput · Prediction Acc.</div>
        <div className="h-40 min-w-0 relative">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={history} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="t" tick={{ fontSize: 9, fill: "#94a3b8" }} />
              <YAxis tick={{ fontSize: 9, fill: "#94a3b8" }} />
              <Tooltip contentStyle={{ background: "rgba(10,15,28,0.95)", border: "1px solid rgba(255,255,255,0.1)", fontSize: 11 }} />
              <Line type="monotone" dataKey="throughput" stroke="#a3e635" dot={false} strokeWidth={1.5} />
              <Line type="monotone" dataKey="predAcc" stroke="#a78bfa" dot={false} strokeWidth={1.5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export function IncidentPanel() {
  const trigger = useTwin((s) => s.triggerIncident);
  const alerts = useTwin((s) => s.alerts);
  const incidents = useTwin((s) => s.incidents);
  const active = incidents.filter((i) => !i.resolvedAt).length;
  const btn = "glass rounded-lg px-2.5 py-2 text-[11px] hover:bg-white/5 transition border border-white/5 flex-1";
  return (
    <div className="glass rounded-xl p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground">Incident Simulator</div>
        <span className="text-[10px] font-mono text-amber">{active} active</span>
      </div>
      <div className="flex gap-1.5">
        <button className={btn} onClick={() => trigger("block")}>🚧 Road Block</button>
        <button className={btn} onClick={() => trigger("accident")}>💥 Accident</button>
        <button className={btn} onClick={() => trigger("construction")}>🏗 Const.</button>
        <button className={btn} onClick={() => trigger("emergency")}>🚨 Emerg.</button>
      </div>
      <div className="mt-3 max-h-40 overflow-auto scrollbar-thin space-y-1">
        {alerts.length === 0 && <div className="text-[10px] text-muted-foreground">No alerts yet — trigger an incident.</div>}
        {alerts.map((a) => (
          <div key={a.id} className="flex items-start gap-2 text-[10px] font-mono">
            <span className={
              a.level === "crit" ? "text-destructive"
              : a.level === "warn" ? "text-amber"
              : "text-cyan"
            }>●</span>
            <span className="text-muted-foreground tabular-nums">t={a.t}</span>
            <span className="text-foreground truncate">{a.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function SimControls() {
  const { running, start, stop, reset, useAISMROS, toggleAISMROS, speed, setSpeed, tick } = useTwin();
  return (
    <div className="glass rounded-xl p-3 flex flex-wrap items-center gap-2">
      <button
        onClick={running ? stop : start}
        className={"px-3 py-1.5 rounded-md text-xs font-semibold " + (running ? "bg-destructive text-destructive-foreground" : "bg-primary text-primary-foreground")}>
        {running ? "■ Pause" : "▶ Start"}
      </button>
      <button onClick={reset} className="px-3 py-1.5 rounded-md text-xs glass border border-white/5">Reset</button>
      <label className="flex items-center gap-2 text-[11px] ml-1">
        <input type="checkbox" checked={useAISMROS} onChange={(e) => toggleAISMROS(e.target.checked)} className="accent-cyan-400" />
        <span className="text-muted-foreground">AI-SMROS Routing</span>
      </label>
      <div className="flex items-center gap-2 text-[11px] ml-auto">
        <span className="text-muted-foreground">Speed</span>
        <input type="range" min={1} max={20} value={speed} onChange={(e) => setSpeed(+e.target.value)} className="w-24 accent-cyan-400" />
        <span className="font-mono text-cyan w-6">{speed}×</span>
      </div>
      <div className="text-[10px] font-mono text-muted-foreground w-full md:w-auto">tick t={tick} · {(tick / 60).toFixed(2)} sim-hours</div>
    </div>
  );
}
