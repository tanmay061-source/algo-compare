// Server functions exposed as a typed RPC "REST API".
// These can be called from client code (useServerFn / direct call) or via
// the auto-generated /_serverFn endpoints under the hood.
import { createServerFn } from "@tanstack/react-start";
import { buildNetwork, applyTrafficContext } from "@/lib/rtsma/network";
import { generateDataset, datasetStats, correlation } from "@/lib/rtsma/dataset";
import { stepRTSMA, stepACO, stepPSO, defaultParams, type AlgoParams } from "@/lib/rtsma/algorithms";

function snap<T>(o: T): T { return JSON.parse(JSON.stringify(o)); }

/** /init — initialize a fresh network + dataset. */
export const apiInit = createServerFn({ method: "GET" })
  .inputValidator((d: { seed?: number; nodes?: number }) => d)
  .handler(async ({ data }) => {
    const seed = data.seed ?? 42;
    const net = buildNetwork(data.nodes ?? 22, seed);
    const dataset = generateDataset(120, seed);
    return {
      nodes: net.nodes, edges: net.edges, source: net.source, sink: net.sink,
      datasetSize: dataset.length, stats: datasetStats(dataset),
    };
  });

/** /update — run N simulation steps and return the latency/energy series. */
export const apiUpdate = createServerFn({ method: "POST" })
  .inputValidator((d: { seed?: number; steps?: number; params?: Partial<AlgoParams> }) => d)
  .handler(async ({ data }) => {
    const seed = data.seed ?? 42;
    const steps = Math.min(80, Math.max(1, data.steps ?? 20));
    const net = buildNetwork(22, seed);
    const dataset = generateDataset(120, seed);
    const params: AlgoParams = { ...defaultParams, ...(data.params ?? {}) };
    const series: { t: number; rtsma: number; aco: number; pso: number;
      energy_rtsma: number; energy_aco: number; energy_pso: number;
      reliability_rtsma: number }[] = [];
    for (let i = 0; i < steps; i++) {
      const row = dataset[i % dataset.length];
      applyTrafficContext(net, row);
      params.predictedFlow = row.flow_rate;
      const rtNet = snap(net);
      const r = stepRTSMA(rtNet, params);
      const a = stepACO(snap(net), params);
      const p = stepPSO(snap(net), params);
      net.edges.forEach((e, j) => { e.conductivity = rtNet.edges[j].conductivity; });
      series.push({
        t: i,
        rtsma: r.metrics.avgLatency, aco: a.metrics.avgLatency, pso: p.metrics.avgLatency,
        energy_rtsma: r.metrics.energy, energy_aco: a.metrics.energy, energy_pso: p.metrics.energy,
        reliability_rtsma: r.metrics.reliability,
      });
    }
    const avg = (k: keyof (typeof series)[number]) =>
      series.reduce((s, x) => s + (x[k] as number), 0) / Math.max(1, series.length);
    return {
      steps: series.length,
      series,
      summary: {
        rtsma: { avgLatency: avg("rtsma"), avgEnergy: avg("energy_rtsma"), avgReliability: avg("reliability_rtsma") },
        aco: { avgLatency: avg("aco"), avgEnergy: avg("energy_aco") },
        pso: { avgLatency: avg("pso"), avgEnergy: avg("energy_pso") },
      },
    };
  });

/** /state — return current synthetic network state. */
export const apiState = createServerFn({ method: "GET" })
  .inputValidator((d: { seed?: number }) => d)
  .handler(async ({ data }) => {
    const net = buildNetwork(22, data.seed ?? 42);
    return { nodes: net.nodes, edges: net.edges };
  });

/** /metrics — convenience: just the summary from a 30-step run. */
export const apiMetrics = createServerFn({ method: "GET" })
  .inputValidator((d: { seed?: number }) => d)
  .handler(async ({ data }) => {
    const out = await apiUpdate({ data: { seed: data.seed, steps: 30 } });
    return out.summary;
  });

/** /graphs — distributions and correlation matrix from the dataset. */
export const apiGraphs = createServerFn({ method: "GET" })
  .inputValidator((d: { seed?: number }) => d)
  .handler(async ({ data }) => {
    const dataset = generateDataset(120, data.seed ?? 42);
    return {
      stats: datasetStats(dataset),
      correlation: correlation(dataset),
      flowSamples: dataset.map((r) => r.flow_rate),
      latencySamples: dataset.map((r) => r.latency),
      attackRatio: dataset.filter((r) => r.attack_flag).length / dataset.length,
    };
  });
